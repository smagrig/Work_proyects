const PORT = 3000;
const SUPABASE_URL = "https://cyiroqtwrgsziojhcqzk.supabase.co";
const SUPABASE_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN5aXJvcXR3cmdzemlvamhjcXprIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTczMDM3MzMwMCwiZXhwIjoyMDQ1OTQ5MzAwfQ.moVoGlPS3CgCcgcQz1w1qFKB6e8ej2J_KNRDjM3DjAc";
module.exports = {
  PORT,
  SUPABASE_URL,
  SUPABASE_KEY,
};
