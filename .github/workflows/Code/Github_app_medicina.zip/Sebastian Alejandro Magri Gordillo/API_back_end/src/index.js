const express = require("express");
const morgan = require("morgan");
const { PORT } = require("./config");
const cors = require('cors');
const app = express();

app.set("port", PORT);
// Middleware CORS configurado antes de las rutas
app.use(
  cors({
    origin: "*", // Asegúrate de especificar el dominio exacto en lugar de "*"
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true, // Permitir el envío de cookies o cabeceras con autenticación
  })
);


//middlewares
app.use(morgan("dev"));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use(require("./routes/index"));
app.use("/api/movies", require("./routes/movies"));
app.use("/api/user", require("./routes/user"));
app.use("/api/pacientes", require("./routes/pacientes"));
app.use("/api/administrador", require("./routes/administrador"));
app.use("/api/specialist", require("./routes/especialista"));
app.use("/api/login", require("./routes/login"));



app.listen(PORT, () => {
  console.log("Server is running on port", app.get("port"));
});


