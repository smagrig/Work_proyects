const { Router } = require("express");

const router = Router();

// routes
router.use("/test", (req, res) => {
  const data = {
    name: "John Doe",
    website: "johndoe.com",
  };

  res.json(data);
});

module.exports = router;
