# Databricks notebook source
# MAGIC %md 
# MAGIC <h1> NO EDITAR, POR FAVOR CLONARLO Y TRABAJAR EN SU PROPIO WORKSPACE <h/1>
# MAGIC <h5> NOTA: No es para uso de requerimientos, usar el notebook llamado "Sacar redes (requerimientos)"

# COMMAND ----------

from datetime import date
from pyspark.sql.types import *
from pyspark.sql.functions import approxCountDistinct,col,pandas_udf,udf,when,create_map,lit,sum,count
from itertools import chain
from pyspark import StorageLevel
fecha_actual=str(date.today())
anio_actual=date.today().year
ruta_base = 'abfss://sandbox@sadiaribigdata.dfs.core.windows.net/' # ruta del azure storage explorer

# COMMAND ----------

# MAGIC %md
# MAGIC ## Definición de parámetros y funciones
# MAGIC Acá se leen los 5 parámetros de entrada:
# MAGIC <ul>
# MAGIC <li><b>Año inicial: </b> Año desde el cual se buscan los contratos. Default: 2020
# MAGIC <li><b>Año final: </b> Año hasta el cual se buscan los contratos. Default: Año actual
# MAGIC <li><b>FORMATO EXPORTACIÓN: </b> Exportar en formato .csv o .xlsx.
# MAGIC <li><b>SIGEDOC: </b> Número del SIGEDOC o nombre de investigación para nombrar tabla origen en el catálogo. Ejemplo: 2024IEXXXXXX
# MAGIC <li><b>TIPO BÚSQUEDA: </b> Si se requiere buscar las identificaciones por CONTRATISTA, CONTRATANTE o por AMBOS.
# MAGIC <li><b>Ruta del archivo </b> Ubicación del archivo BUSCAR.csv en el sandbox de Azure storage explorer. Ej: /analista01/MDLO_CONTRACTUAL/requerimientos/TEST_OPJ (Solo debe estar dicho archivo)
# MAGIC <li><b> TOP: </b> Dejar vacío si se va a usar el archivo BUSCAR. SOLO usar cuando son investigaciones del  TOP de contratistas 
# MAGIC <ul/>

# COMMAND ----------

#dbutils.widgets.removeAll()

# COMMAND ----------

# DBTITLE 1,Parámetro que indica la vigencia de busqueda
anio_inicial=dbutils.widgets.text("Año inicial", "2020", "Año desde que se inicia la busqueda")
anio_inicial = dbutils.widgets.get("Año inicial")
anio_final=dbutils.widgets.text("Año final", f"{anio_actual}", "Año final de la busqueda")
anio_final = dbutils.widgets.get("Año final")
print(f'La búsqueda será entre los años {anio_inicial} y {anio_final}')

# COMMAND ----------

# DBTITLE 1,Parámetro que indica si la búsqueda es por contratista o contratante
dbutils.widgets.dropdown("TIPO BÚSQUEDA", "AMBOS CASOS", ["CONTRATISTA", "CONTRATANTE","AMBOS CASOS"])
tipo_busqueda = dbutils.widgets.get("TIPO BÚSQUEDA")
tipo_busqueda

# COMMAND ----------

# DBTITLE 1,Parámetro que indica el modo de exportación de los archivos
dbutils.widgets.dropdown("FORMATO EXPORTACIÓN", "csv", ["csv", "excel"])
formato = dbutils.widgets.get("FORMATO EXPORTACIÓN")
formato

# COMMAND ----------

# DBTITLE 1,Parámetro que indica el sigedoc o nombre de la investigación
sigedoc=dbutils.widgets.text("Sigedoc o Nombre Investigación", "", "SIGEDOC o Nombre Investigación")
sigedoc = dbutils.widgets.get("Sigedoc o Nombre Investigación")
sigedoc

# COMMAND ----------

# DBTITLE 1,Parámetro que indica la ubicación del archivo a buscar
ruta=dbutils.widgets.text("Ruta del archivo", "", "Ubicación archivo BUSCAR en storage explorer")
ruta_req = dbutils.widgets.get("Ruta del archivo")
ruta_completa = f"{ruta_base}/{ruta_req}" # concatenar ruta base + ruta requerimiento
ruta_completa

# COMMAND ----------

# DBTITLE 1,Parámetro que indica qué top de contratistas se va a buscar
## Dejar vacío si se trata de un caso diferente al TOP de contratistas
top =dbutils.widgets.text("Limite TOP", "", "Límite del TOP buscado")
top = dbutils.widgets.get("Limite TOP")
top

# COMMAND ----------

chunksize=1000000
def escribir_excel(df,name):  
    """Writes a Spark DataFrame to one or multiple Excel files, depending on its size.
    Args:
        df (pyspark.sql.DataFrame): The Spark DataFrame to be written to Excel.
        name (str): The base name for the Excel files.
    Raises:
        ValueError: If the chunksize is less than or equal to 0.
    Notes:
        - Requires the 'com.crealytics.spark.excel' format for Excel writing.
        - Writes multiple files if the DataFrame size exceeds a specified chunksize.
        - Uses 'ruta_completa' (assumed to be a global variable) for the file path.
    """
    num_archivos =  round(df.count()/chunksize)
    if num_archivos>1:
        for archivo in range(1,num_archivos+1):
            spark.createDataFrame(df.collect()[(archivo-1)*chunksize:archivo*chunksize][:]).write.format("com.crealytics.spark.excel").option("header", "true").mode("overwrite").save(ruta_completa + f"/{name}_{archivo}.xlsx")
    else:
        df.write.format("com.crealytics.spark.excel").option("header", "true").mode("overwrite").save(ruta_completa + f"/{name}.xlsx")

# COMMAND ----------

def escribir_csv(df,name):
     """
     Write a DataFrame to a CSV file with specified options.

     Parameters:
     - df (pyspark.sql.DataFrame): The DataFrame to be written to a CSV file.
     - name (str): The name of the CSV file to be generated.

     Returns:
     None

     Raises:
     None

     Usage:
     escribir_csv(df, name)

     This function takes a PySpark DataFrame (`df`) and a string (`name`) as input.
     It writes the DataFrame to a CSV file using the specified options, such as overwriting
     existing files, including headers, using the ISO-8859-1 encoding, and setting the
     delimiter as a semicolon (;). The resulting CSV file is saved in the specified location
     with the given name.
     """
     df.coalesce(1).write.format('com.databricks.spark.csv').mode('overwrite').option('header', 'true').option('encoding','ISO-8859-1').option('sep', ';').save(ruta_completa + f"/{name}")

# COMMAND ----------

def exportar_archivo(df,name,formato):
    """
    Export a DataFrame to a file in the specified format.

    Parameters:
    - df (pandas.DataFrame or pyspark.sql.DataFrame): The DataFrame to be exported.
    - name (str): The name of the file to be generated.
    - formato (str): The format in which the file should be exported. Supported formats: 'excel', 'csv'.

    Returns:
    None

    Raises:
    ValueError: If the specified format is not supported.

    Usage:
    exportar_archivo(df, name, formato)

    This function takes a DataFrame (`df`), a string (`name`) specifying the file name,
    and a string (`formato`) indicating the desired file format ('excel' or 'csv'). 
    If the format is 'excel', the DataFrame is exported to an Excel file using the 
    escribir_excel function. If the format is 'csv', the DataFrame is exported to a CSV 
    file using the escribir_csv function. Raises a ValueError for unsupported formats.
    """
    if formato=='excel':
        escribir_excel(df,name)
    else:
        escribir_csv(df,name)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparación de la búsqueda
# MAGIC <ol>
# MAGIC <li> Leer archivo BUSCAR.csv en la ubicación definida
# MAGIC <li> Creación de tabla de búsqueda en mdlo_contractual.requerimientos.SIGEDOC
# MAGIC <li> Revisión de primeras filas de la información escrita
# MAGIC </ol>

# COMMAND ----------

if top=='':
    if '.xls' in [element.path for element in dbutils.fs.ls(ruta_completa) if 'BUSCAR' in element.path][0]:
        buscar_csv = spark.read.format("com.crealytics.spark.excel").option("useHeader", "true").option('header','true').schema(StructType([StructField('NIT',StringType(),True)])).load(ruta_completa+'BUSCAR.xlsx')
    else:
        buscar_csv = spark.read.csv(ruta_completa+'BUSCAR.csv', header=True, encoding='ISO-8859-1')
    buscar_csv.write.option("overwriteSchema", "true").mode("overwrite").saveAsTable(f"mdlo_contractual.requerimientos.{sigedoc}")
else:
    spark.sql(f"""CREATE OR REPLACE TABLE mdlo_contractual.requerimientos.{sigedoc} AS (SELECT IDENTIFICACION_CONTRATISTA AS NIT,SUM(VALOR_TOTAL_CONTRATO) AS VALOR_TOTAL_CONTRATO  FROM mdlo_contractual.reporting.contratacion_consolidada
    WHERE FECHA_SUSCRIPCION>='2022-08-07' AND FUENTE LIKE '%SECOP%' AND IDENTIFICACION_CONTRATISTA!='NO DEFINIDO'
    GROUP BY IDENTIFICACION_CONTRATISTA
    ORDER BY VALOR_TOTAL_CONTRATO DESC
    LIMIT {top})""")
df_original=spark.sql(f"select * from mdlo_contractual.requerimientos.{sigedoc}")
display(df_original.limit(10))

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Sacar los familiares

# COMMAND ----------

df_familiares=spark.sql(f"""
SELECT F.* 
FROM mdlo_contractual.insumos.vinculos_familiares F
INNER JOIN mdlo_contractual.requerimientos.{sigedoc} S ON F.ID_FAMILIAR1=S.NIT OR F.ID_FAMILIAR2=S.NIT""").persist(StorageLevel.MEMORY_AND_DISK)
display(df_familiares.limit(10))

# COMMAND ----------

exportar_archivo(df_familiares,'Familiares',formato)

# COMMAND ----------

df_original.select('NIT').union(df_familiares.select('ID_FAMILIAR1')).union(df_familiares.select('ID_FAMILIAR2')).dropDuplicates().createOrReplaceTempView('familiares')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sacar los integrantes
# MAGIC <ol>
# MAGIC <li> Se define una blacklist de nits correspondientes a bancos, aseguradoras etc cuyas relaciones no son objeto de estudio.
# MAGIC <li> Se extraen tantos los integrantes como las entidades asociadas a las identificaciones buscadas.
# MAGIC <li> Con el universo anterior se vuelve a realizar la búsqueda por entidad e integrante para sacar relaciones finales (Es decir, que en el caso de Consorcios o UT se encuentren las empresas que lo conforman y posteriormente los representantes legales de dichas empresas)
# MAGIC <li> Se exporta archivo de Integrantes en la ubicación ingresada
# MAGIC </ol>

# COMMAND ----------

BLACKLIST = ['860026182','860524654','860002184','900814916','860026518',
'860049275','860004875','900488151','860039988','860002527',
'860011153','860002400','860009195','860031979','860002503',
'860070374','860009578','860028415','891700037','860037013',
'890903407','860002534','811001904']

df_integrantes_consultados=spark.sql(f"""
WITH PRE AS (
select  I.ID_ENTIDAD,I.ID_INTEGRANTE from  mdlo_contractual.reporting.integrantes I 
INNER JOIN familiares S ON I.ID_ENTIDAD=S.NIT
UNION ALL
select  I.ID_ENTIDAD,I.ID_INTEGRANTE from  mdlo_contractual.reporting.integrantes I  
INNER JOIN familiares S ON I.ID_INTEGRANTE=S.NIT
),

PRE2 AS (
select distinct ID_ENTIDAD AS NIT FROM PRE UNION SELECT distinct ID_INTEGRANTE FROM PRE
)

select distinct FUENTE,	ID_ENTIDAD,	mdlo_contractual.reporting.limpieza_texto_sencilla(NOMBRE_ENTIDAD) as NOMBRE_ENTIDAD,	TIPO_ENTIDAD,	TIPO_RELACION,	FECHA_RELACION,	ID_INTEGRANTE,	mdlo_contractual.reporting.limpieza_texto_sencilla(NOMBRE_INTEGRANTE) as NOMBRE_INTEGRANTE,	TIPO_INTEGRANTE,	TIPO_ID_INTEGRANTE from  mdlo_contractual.reporting.integrantes I 
INNER JOIN PRE2 S ON S.NIT=I.ID_ENTIDAD 
WHERE LEN(ID_INTEGRANTE) > 4 AND LEN(ID_ENTIDAD) > 4 AND ID_INTEGRANTE IS NOT NULL AND ID_ENTIDAD IS NOT NULL AND ID_INTEGRANTE <> '' AND ID_ENTIDAD <> '' AND ID_INTEGRANTE NOT IN {tuple(BLACKLIST)} AND ID_ENTIDAD NOT IN {tuple(BLACKLIST)}
UNION
select distinct FUENTE,	ID_ENTIDAD,	mdlo_contractual.reporting.limpieza_texto_sencilla(NOMBRE_ENTIDAD) as NOMBRE_ENTIDAD,	TIPO_ENTIDAD,	TIPO_RELACION,	FECHA_RELACION,	ID_INTEGRANTE,	mdlo_contractual.reporting.limpieza_texto_sencilla(NOMBRE_INTEGRANTE) as NOMBRE_INTEGRANTE,	TIPO_INTEGRANTE,TIPO_ID_INTEGRANTE from  mdlo_contractual.reporting.integrantes I  
INNER JOIN PRE2 S ON S.NIT=I.ID_INTEGRANTE 
WHERE LEN(ID_INTEGRANTE) > 4 AND LEN(ID_ENTIDAD) > 4 AND ID_INTEGRANTE IS NOT NULL AND ID_ENTIDAD IS NOT NULL AND ID_INTEGRANTE <> '' AND ID_ENTIDAD <> ''AND ID_INTEGRANTE NOT IN {tuple(BLACKLIST)} AND ID_ENTIDAD NOT IN {tuple(BLACKLIST)}
""").persist(StorageLevel.MEMORY_AND_DISK)
display(df_integrantes_consultados.limit(10))

# COMMAND ----------

# DBTITLE 1,Crear archivo Integrantes
exportar_archivo(df_integrantes_consultados,'Integrantes',formato)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sacar contratos
# MAGIC <ol>
# MAGIC <li> De acuerdo al tipo de búsqueda se buscan todas las identificaciones de integrantes en la base de contratación por CONTRATISTA, CONTRATANTE o por AMBOS en las vigencias (años) especificados.
# MAGIC <li> Se exportan los resultados en un archivo de excel llamado "Contratos.xlsx" en la ubicación diligenciada previamente
# MAGIC </ol>

# COMMAND ----------

df_integrantes_consultados.select('ID_ENTIDAD').union(df_integrantes_consultados.select('ID_INTEGRANTE')).union(df_original.select('NIT')).union(df_familiares.select('ID_FAMILIAR1')).union(df_familiares.select('ID_FAMILIAR2')).dropDuplicates().withColumnRenamed('ID_ENTIDAD','IDENTIFICACION').createOrReplaceTempView("df_integrantes_consultados")
if tipo_busqueda=='CONTRATISTA':
    df_contratos=spark.sql(f""" SELECT FUENTE,ID_CONTRATO,NUMERO_CONTRATO,MODALIDAD,NIT_ENTIDAD,NOMBRE_ENTIDAD, IDENTIFICACION_CONTRATISTA, NOMBRE_CONTRATISTA,FECHA_INICIO,FECHA_FIN,PLAZO_EJEC_CONTRATO,FECHA_SUSCRIPCION,ANO_SUSCRIPCION,VALOR_TOTAL_CONTRATO,OBJETO_CONTRATO,DEPTO_AJUST,MUNI_AJUST,SECTOR,SUBSECTOR,ESTADO_CONTRATO,NOMBRE_CONTRATISTA_STD,NOMBRE_ENTIDAD_STD,ENLACE,ORIGEN_RECURSOS
    FROM mdlo_contractual.reporting.contratacion_consolidada C INNER JOIN df_integrantes_consultados I ON C.IDENTIFICACION_CONTRATISTA = I.IDENTIFICACION
    WHERE IDENTIFICACION_CONTRATISTA IS NOT NULL and IDENTIFICACION_CONTRATISTA NOT IN ('', 'NO DEFINIDO') AND LEN(IDENTIFICACION_CONTRATISTA) > 4
    AND ANO_SUSCRIPCION BETWEEN {anio_inicial} AND {anio_final}""").persist(StorageLevel.MEMORY_AND_DISK)
elif tipo_busqueda =='CONTRATANTE':
    df_contratos=spark.sql(f""" SELECT FUENTE,ID_CONTRATO,NUMERO_CONTRATO,MODALIDAD,NIT_ENTIDAD,NOMBRE_ENTIDAD, IDENTIFICACION_CONTRATISTA, NOMBRE_CONTRATISTA,FECHA_INICIO,FECHA_FIN,PLAZO_EJEC_CONTRATO,FECHA_SUSCRIPCION,ANO_SUSCRIPCION,VALOR_TOTAL_CONTRATO,OBJETO_CONTRATO,DEPTO_AJUST,MUNI_AJUST,SECTOR,SUBSECTOR,ESTADO_CONTRATO,NOMBRE_CONTRATISTA_STD,NOMBRE_ENTIDAD_STD,ENLACE,ORIGEN_RECURSOS
    FROM mdlo_contractual.reporting.contratacion_consolidada C INNER JOIN df_integrantes_consultados I ON C.NIT_ENTIDAD = I.IDENTIFICACION
    WHERE NIT_ENTIDAD IS NOT NULL and NIT_ENTIDAD NOT IN ('', 'NO DEFINIDO') AND LEN(NIT_ENTIDAD) > 4
    AND ANO_SUSCRIPCION BETWEEN {anio_inicial} AND {anio_final}""").persist(StorageLevel.MEMORY_AND_DISK)
else:
    df_contratos=spark.sql(f"""SELECT FUENTE,ID_CONTRATO,NUMERO_CONTRATO,MODALIDAD,NIT_ENTIDAD,NOMBRE_ENTIDAD, IDENTIFICACION_CONTRATISTA, NOMBRE_CONTRATISTA,FECHA_INICIO,FECHA_FIN,PLAZO_EJEC_CONTRATO,FECHA_SUSCRIPCION,ANO_SUSCRIPCION,VALOR_TOTAL_CONTRATO,OBJETO_CONTRATO,DEPTO_AJUST,MUNI_AJUST,SECTOR,SUBSECTOR,ESTADO_CONTRATO,NOMBRE_CONTRATISTA_STD,NOMBRE_ENTIDAD_STD,ENLACE,ORIGEN_RECURSOS
    FROM mdlo_contractual.reporting.contratacion_consolidada C INNER JOIN df_integrantes_consultados I ON C.IDENTIFICACION_CONTRATISTA = I.IDENTIFICACION
    WHERE IDENTIFICACION_CONTRATISTA IS NOT NULL and IDENTIFICACION_CONTRATISTA NOT IN ('', 'NO DEFINIDO') AND LEN(IDENTIFICACION_CONTRATISTA) > 4 AND ANO_SUSCRIPCION BETWEEN {anio_inicial} AND {anio_final}
    UNION
    SELECT FUENTE,ID_CONTRATO,NUMERO_CONTRATO,MODALIDAD,NIT_ENTIDAD,NOMBRE_ENTIDAD, IDENTIFICACION_CONTRATISTA, NOMBRE_CONTRATISTA,FECHA_INICIO,FECHA_FIN,PLAZO_EJEC_CONTRATO,FECHA_SUSCRIPCION,ANO_SUSCRIPCION,VALOR_TOTAL_CONTRATO,OBJETO_CONTRATO,DEPTO_AJUST,MUNI_AJUST,SECTOR,SUBSECTOR,ESTADO_CONTRATO,NOMBRE_CONTRATISTA_STD,NOMBRE_ENTIDAD_STD,ENLACE ,ORIGEN_RECURSOS
    FROM mdlo_contractual.reporting.contratacion_consolidada C INNER JOIN df_integrantes_consultados I ON C.NIT_ENTIDAD = I.IDENTIFICACION
    WHERE NIT_ENTIDAD IS NOT NULL and NIT_ENTIDAD NOT IN ('', 'NO DEFINIDO') AND LEN(NIT_ENTIDAD) > 4
    AND ANO_SUSCRIPCION BETWEEN {anio_inicial} AND {anio_final}""").persist(StorageLevel.MEMORY_AND_DISK)
df_contratos = df_contratos.withColumn("VALOR_TOTAL_CONTRATO", col("VALOR_TOTAL_CONTRATO").cast('bigint'))

# COMMAND ----------

display(df_contratos.limit(5))

# COMMAND ----------

# DBTITLE 1,Crear archivo Contratos
exportar_archivo(df_contratos,'Contratos',formato)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sacar sanciones
# MAGIC <ol>
# MAGIC <li> De acuerdo al tipo de búsqueda se buscan todas las identificaciones de integrantes en la base de sanciones.
# MAGIC <li> Se exportan los resultados en un archivo de excel llamado "Sanciones.xlsx" en la ubicación diligenciada previamente
# MAGIC </ol>

# COMMAND ----------

df_sanciones=spark.sql(f""" 
SELECT S.* 
FROM mdlo_contractual.reporting.sanciones S INNER JOIN df_integrantes_consultados I ON S.ID_SANCIONADO = I.IDENTIFICACION
WHERE ID_SANCIONADO IS NOT NULL AND ID_SANCIONADO <> '' AND LEN(ID_SANCIONADO) > 4""")
df_sanciones = df_sanciones.withColumn("CUANTIA", col("CUANTIA").cast("bigint"))

# COMMAND ----------

# DBTITLE 1,Crear archivo Sanciones
exportar_archivo(df_sanciones,'Sanciones',formato)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sacar aportantes
# MAGIC <ol>
# MAGIC <li> De acuerdo al tipo de búsqueda se buscan todas las identificaciones de integrantes en la base de Aportantes a campaña.
# MAGIC <li> Se exportan los resultados en un archivo de excel llamado "Aportantes" con el formato especificado y en la ubicación diligenciada previamente
# MAGIC </ol>

# COMMAND ----------

df_aportantes=spark.sql(f""" SELECT distinct A.* FROM mdlo_contractual.reporting.ingresos_aportantes A INNER JOIN df_integrantes_consultados I ON A.ID_APORTANTE = I.IDENTIFICACION """)

# COMMAND ----------

# DBTITLE 1,Crear archivo Aportantes
exportar_archivo(df_aportantes,'Aportantes',formato)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sacar archivo de nodos completo con información útil para graficar en i2
# MAGIC <ol>
# MAGIC <li> Se genera un archivo adicional que contiene la columna MARCA con información de dónde sale el nodo, en las siguientes categorías: 
# MAGIC <ul>
# MAGIC <li> <b>BUSCADO:</b> Si es uno de la lista original que se va a buscar
# MAGIC <li> <b>FAMILIAR:</b> Si dicha persona es encontrada por vínculos familiares de BDUA o DAFP
# MAGIC <li> <b>INTEGRANTE:</b> Si dicha persona es encontrada por vínculos societarios
# MAGIC </ul>
# MAGIC <li> Se calculan las cifras de número de contratos, número de vínculos y valor de los contratos para cada nodo a primer y segundo grado. Se colocan en las columnas  <i> VALOR_TOTAL_CONTRATOS_DIRECTOS	NUMERO_CONTRATOS_DIRECTOS	VALOR_TOTAL_CONTRATOS_NIVEL1	NUMERO_CONTRATOS_NIVEL1	NUMERO_VINCULOS_NIVEL1	VALOR_TOTAL_CONTRATOS_NIVEL2	NUMERO_CONTRATOS_NIVEL2	NUMERO_VINCULOS_NIVEL2	</i>
# MAGIC <li> Se calculan las siguientes variables: <i> VALOR_CONTRATOS_INDIRECTOS	NUMERO_CONTRATOS_INDIRECTOS	NUMERO_VINCULOS_INDIRECTOS	</i> sumando lo que hay en NIVEL 1 y 2
# MAGIC <li> Finalmente se exportan los archivos DETALLE_ENLACES_NIVEL1 y DETALLE_ENLACES_NIVEL2, en caso que se requiera saber cuáles son las conexiones y validar información manualmente.
# MAGIC </ol>

# COMMAND ----------

# Esta parte extrae todos los posibles nodos usando los spark dataframes previamente calculados
df_nodos=df_original.withColumn('MARCA',lit('BUSCADO')).union(df_familiares.select('ID_FAMILIAR1').union(df_familiares.select('ID_FAMILIAR2')).withColumn('MARCA',lit('FAMILIAR')))\
.union(df_integrantes_consultados.select('ID_ENTIDAD').union(df_integrantes_consultados.select('ID_INTEGRANTE')).withColumn('MARCA',lit('INTEGRANTE'))).dropDuplicates(['NIT'])
exportar_archivo(df_nodos,'NODOS',formato)

# COMMAND ----------

# Esta parte es para cargar archivos de la red en caso que se haya apagado el clúster y se requiera analizar. 
from pyspark.sql.types import *
from pyspark.sql.functions import approxCountDistinct,col,pandas_udf,udf,when,create_map,lit,sum,count,concat_ws,collect_list,first
from pyspark import StorageLevel

ruta_base = 'abfss://sandbox@sadiaribigdata.dfs.core.windows.net/' # ruta del azure storage explorer
ruta_req = dbutils.widgets.get("Ruta del archivo")
ruta_completa = f"{ruta_base}/{ruta_req}" # concatenar ruta base + ruta requerimiento
formato = dbutils.widgets.get("FORMATO EXPORTACIÓN")
df_nodos = spark.read.csv(ruta_completa+'NODOS', header=True, encoding='ISO-8859-1',sep=";")
df_integrantes_consultados=spark.read.csv(ruta_completa+'Integrantes', header=True, encoding='ISO-8859-1',sep=";")
df_integrantes=spark.read.csv(ruta_completa+'Integrantes', header=True, encoding='ISO-8859-1',sep=";")
df_contratos = spark.read.csv(ruta_completa+'Contratos', header=True, encoding='ISO-8859-1',sep=";")
df_familiares = spark.read.csv(ruta_completa+'Familiares', header=True, encoding='ISO-8859-1',sep=";")
df_sanciones = spark.read.csv(ruta_completa+'Sanciones', header=True, encoding='ISO-8859-1',sep=";")
df_aportantes = spark.read.csv(ruta_completa+'Aportantes', header=True, encoding='ISO-8859-1',sep=";")

# COMMAND ----------

# Se agrupan cantidades de contratos por contratistas
df_contratos = df_contratos.select('IDENTIFICACION_CONTRATISTA','VALOR_TOTAL_CONTRATO','ID_CONTRATO').withColumn("VALOR_TOTAL_CONTRATO", col("VALOR_TOTAL_CONTRATO").cast(DoubleType()))
df_contratos = df_contratos.groupBy('IDENTIFICACION_CONTRATISTA').agg(sum(col('VALOR_TOTAL_CONTRATO')).alias('VALOR_TOTAL_CONTRATOS'),count(col('ID_CONTRATO')).alias('NUMERO_CONTRATOS'))
df_sanciones=df_sanciones.groupBy('ID_SANCIONADO').agg(concat_ws(' | ',collect_list(col("DETALLE_SANCION"))).alias("DETALLE_SANCION"),count(col('ID_SANCION')).alias('NUMERO_SANCIONES')).limit(2)
display(df_contratos.limit(2))

# COMMAND ----------

#Se calculan todos aquellos vínculos a primer y segundo nivel y se les colocan las variables de contratación previamente calculadas a cada uno de los nodos vinculados
enlaces_nivel_1=df_nodos.join(df_integrantes,df_nodos['NIT']==df_integrantes['ID_ENTIDAD']).select('NIT','ID_INTEGRANTE').union(df_nodos.join(df_integrantes,df_nodos['NIT']==df_integrantes['ID_INTEGRANTE']).select('NIT','ID_ENTIDAD')).dropDuplicates().withColumnRenamed('ID_INTEGRANTE','ID_INTEGRANTE_NIVEL1').where('NIT!=ID_INTEGRANTE_NIVEL1')
enlaces_nivel_1=enlaces_nivel_1.join(df_contratos,df_contratos['IDENTIFICACION_CONTRATISTA']==enlaces_nivel_1['ID_INTEGRANTE_NIVEL1']).select(['NIT','ID_INTEGRANTE_NIVEL1','VALOR_TOTAL_CONTRATOS','NUMERO_CONTRATOS']).withColumnRenamed('VALOR_TOTAL_CONTRATOS','VALOR_TOTAL_CONTRATOS_NIVEL1').withColumnRenamed('NUMERO_CONTRATOS','NUMERO_CONTRATOS_NIVEL1')
enlaces_nivel_2=enlaces_nivel_1.join(df_integrantes,enlaces_nivel_1['ID_INTEGRANTE_NIVEL1']==df_integrantes['ID_ENTIDAD']).select('NIT','ID_INTEGRANTE').union(enlaces_nivel_1.join(df_integrantes,enlaces_nivel_1['ID_INTEGRANTE_NIVEL1']==df_integrantes['ID_INTEGRANTE']).select('NIT','ID_ENTIDAD')).dropDuplicates().withColumnRenamed('ID_INTEGRANTE','ID_INTEGRANTE_NIVEL2').where('NIT!=ID_INTEGRANTE_NIVEL2')
enlaces_nivel_2=enlaces_nivel_2.join(df_contratos,df_contratos['IDENTIFICACION_CONTRATISTA']==enlaces_nivel_2['ID_INTEGRANTE_NIVEL2']).select(['NIT','ID_INTEGRANTE_NIVEL2','VALOR_TOTAL_CONTRATOS','NUMERO_CONTRATOS']).withColumnRenamed('VALOR_TOTAL_CONTRATOS','VALOR_TOTAL_CONTRATOS_NIVEL2').withColumnRenamed('NUMERO_CONTRATOS','NUMERO_CONTRATOS_NIVEL2')
display(enlaces_nivel_2.limit(5))

# COMMAND ----------

# Se agrupan las cifras de cada uno de los vínculos por el nivel inicial.
resumen_enlaces_nivel1=enlaces_nivel_1.groupBy('NIT').agg(sum(col('VALOR_TOTAL_CONTRATOS_NIVEL1')).alias('VALOR_TOTAL_CONTRATOS_NIVEL1'),sum(col('NUMERO_CONTRATOS_NIVEL1')).alias('NUMERO_CONTRATOS_NIVEL1'),count(col('ID_INTEGRANTE_NIVEL1')).alias('NUMERO_VINCULOS_NIVEL1'))
resumen_enlaces_nivel2=enlaces_nivel_2.groupBy('NIT').agg(sum(col('VALOR_TOTAL_CONTRATOS_NIVEL2')).alias('VALOR_TOTAL_CONTRATOS_NIVEL2'),sum(col('NUMERO_CONTRATOS_NIVEL2')).alias('NUMERO_CONTRATOS_NIVEL2'),count(col('ID_INTEGRANTE_NIVEL2')).alias('NUMERO_VINCULOS_NIVEL2'))
display(resumen_enlaces_nivel2.limit(5))

# COMMAND ----------

#
df_nodos_completo=df_nodos.join(df_contratos,df_nodos['NIT']==df_contratos['IDENTIFICACION_CONTRATISTA'],how='left').drop('IDENTIFICACION_CONTRATISTA').join(df_sanciones,df_sanciones['ID_SANCIONADO']==df_nodos['NIT'],how='left').drop('ID_SANCIONADO').join(resumen_enlaces_nivel1,on='NIT',how='left').join(resumen_enlaces_nivel2,on='NIT',how='left').withColumnRenamed('VALOR_TOTAL_CONTRATOS','VALOR_TOTAL_CONTRATOS_DIRECTOS').withColumnRenamed('NUMERO_CONTRATOS','NUMERO_CONTRATOS_DIRECTOS')
df_nodos_completo=df_nodos_completo.withColumn('VALOR_CONTRATOS_INDIRECTOS',col('VALOR_TOTAL_CONTRATOS_NIVEL1')+col('VALOR_TOTAL_CONTRATOS_NIVEL2'))
df_nodos_completo=df_nodos_completo.withColumn('NUMERO_CONTRATOS_INDIRECTOS',col('NUMERO_CONTRATOS_NIVEL1')+col('NUMERO_CONTRATOS_NIVEL2'))
df_nodos_completo=df_nodos_completo.withColumn('NUMERO_VINCULOS_INDIRECTOS',col('NUMERO_VINCULOS_NIVEL1')+col('NUMERO_VINCULOS_NIVEL2'))
df_nodos_completo=df_nodos_completo.na.fill(0)
display(df_nodos_completo.orderBy(col('VALOR_CONTRATOS_INDIRECTOS').desc()).limit(10))

# COMMAND ----------

# Exportar todos los archivos de salida
exportar_archivo(df_nodos_completo,'NODOS_COMPLETOS',formato)
exportar_archivo(enlaces_nivel_1,'DETALLE_ENLACES_NIVEL1',formato)
exportar_archivo(enlaces_nivel_2,'DETALLE_ENLACES_NIVEL2',formato)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sacar archivo de enlaces completo con información útil para graficar en i2
# MAGIC <ol>
# MAGIC <li> Se genera un archivo adicional que contiene los enlaces familiares y de integrantes
# MAGIC <li> Se agrupa por ID_NODO1,ID_NODO2 con el fin de generar un único vínculo en i2 separando las diferentes relaciones o fechas por | en caso de tener múltiples vínculos
# MAGIC </ol>

# COMMAND ----------

df_familiares=df_familiares.withColumn('FUENTE',concat_ws(' ',col('FUENTE'),col('GRADO_VINCULO')))
df_enlaces_completo=df_familiares.select(['FUENTE','ID_FAMILIAR1','NOMBRE_FAMILIAR1','ID_FAMILIAR2','NOMBRE_FAMILIAR2','TIPO_RELACION','FECHA_RELACION']).union(df_integrantes_consultados.select(['FUENTE','ID_ENTIDAD','NOMBRE_ENTIDAD','ID_INTEGRANTE','NOMBRE_INTEGRANTE','TIPO_RELACION','FECHA_RELACION'])).withColumnRenamed('ID_FAMILIAR1','ID_NODO1').withColumnRenamed('ID_FAMILIAR2','ID_NODO2').withColumnRenamed('NOMBRE_FAMILIAR1','NOMBRE_NODO1').withColumnRenamed('NOMBRE_FAMILIAR2','NOMBRE_NODO2')

df_enlaces_completo=df_enlaces_completo.groupBy(col("ID_NODO1"), col("ID_NODO2")).agg(first(col("NOMBRE_NODO1")).alias("NOMBRE_NODO1"),first(col("NOMBRE_NODO2")).alias("NOMBRE_NODO2"),concat_ws(' | ',collect_list(col("FUENTE"))).alias("FUENTE"),concat_ws(' | ',collect_list(col("TIPO_RELACION"))).alias("TIPO_RELACION"),concat_ws(' | ',collect_list(col("FECHA_RELACION"))).alias("FECHA_RELACION"))

df_enlaces_completo=df_enlaces_completo.withColumn('FUENTE',col("FUENTE").cast(StringType()))
df_enlaces_completo=df_enlaces_completo.withColumn('TIPO_RELACION',col("TIPO_RELACION").cast(StringType()))
df_enlaces_completo=df_enlaces_completo.withColumn('FECHA_RELACION',col("FECHA_RELACION").cast(StringType()))
exportar_archivo(df_enlaces_completo.select(['FUENTE','ID_NODO1','NOMBRE_NODO1','ID_NODO2','NOMBRE_NODO2','TIPO_RELACION','FECHA_RELACION']),'ENLACES_COMPLETOS',formato)
display(df_enlaces_completo.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sacar archivo de contratos de la UNGRD que no se reportan en la bases de contratación
# MAGIC <ol>
# MAGIC <li> Se genera un archivo que contiene los contratos reportados por la UNGRD. Nos conectamos a la base cd_infr.`900478966`.cdextendidos_fidusap_ungrd_2022 que es actualizada diariamente
# MAGIC <li> Se exportan los resultados en un archivo de excel llamado "Contratos_UNGRD" con el formato especificado y en la ubicación diligenciada previamente
# MAGIC </ol>

# COMMAND ----------

from pyspark import StorageLevel
import re
%pip install unidecode
from unidecode import unidecode
from unicodedata import normalize
from pyspark.sql.functions import regexp_replace, upper, trim
from pyspark.sql.functions import expr
from pyspark.sql import functions as fu


# COMMAND ----------

#Cargo la base original 
df_ungrd = spark.sql(f"Select * from cd_infr.`900478966`.cdextendidos_fidusap_ungrd_2022" ).persist(StorageLevel.MEMORY_AND_DISK)

#Elimino campos y cambio el nombre de los campos para dejar unos estandar
df_ungrd= df_ungrd.drop('DISPONIBILIDAD','VALOR','NO_SOLICITUD','AREA_EJECUTORA','FECHA','VALOR_DISTRIBUIDO','RESOLUCION','REGISTRO_COMPROMISO','FECHA_REGISTRO','SUPERVISOR1','SUPERVISOR2','VALOR_PAGADO','VALOR_POR_PAGAR','NOMBRE_FIRMA','CARGO_FIRMA','FECHA_CARGUE_UI','FECHA_DE_CORTE').withColumnRenamed('DESCRIPCION', 'OBJETO_CONTRATO').withColumnRenamed('FUENTE', 'ORIGEN_RECURSOS').withColumnRenamed('IDENTIFICACION', 'IDENTIFICACION_CONTRATISTA').withColumnRenamed('NOMBRE', 'NOMBRE_CONTRATISTA').withColumnRenamed('ESTADO', 'ESTADO_CONTRATO').withColumnRenamed('VALOR2', 'VALOR_TOTAL_CONTRATO').withColumnRenamed('CONTRATO', 'ID_CONTRATO').withColumnRenamed('FECHA_INICIAL', 'FECHA_INICIO').withColumnRenamed('FECHA_FINAL', 'FECHA_FIN')

#Se hace limpieza al campo de Identificación y creo un campo marca 
df_ungrd = df_ungrd.withColumn('IDENTIFICACION_CONTRATISTA', trim(upper(regexp_replace('IDENTIFICACION_CONTRATISTA', '[^0-9\\s]', '')))).withColumn('MARCA_UNGRD', fu.lit('UNGRD'))

#Se crea una nueva tabla en la base del modelo_contractual
df_ungrd.write.option("overwriteSchema", "true").mode("overwrite").saveAsTable(f"mdlo_contractual.reporting.contratacion_ungrd")

# COMMAND ----------

df_contratos_ungrd=spark.sql(f""" SELECT A.* FROM mdlo_contractual.reporting.contratacion_ungrd A INNER JOIN df_integrantes_consultados I ON A.IDENTIFICACION_CONTRATISTA = I.IDENTIFICACION """)
display(df_contratos_ungrd)

# COMMAND ----------

# DBTITLE 1,Crear archivo Contratos UNGRD
exportar_archivo(df_contratos_ungrd,'Contratos_UNGRD',formato)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Generar archivo de contratistas Alertados por la DIARI
# MAGIC <ol>
# MAGIC <li> Se genera un archivo que contiene los contratistas previamente alertados por la DIARI. Nos conectamos a la base del modelo alertas mdlo_gestion_alertas.vistas.all_seg_alertas_noreg
# MAGIC <li> Se exportan los resultados en un archivo de excel llamado "Alertados_DIARI" con el formato especificado y en la ubicación diligenciada previamente
# MAGIC </ol>

# COMMAND ----------

df_alertados=spark.sql(f""" SELECT distinct( ID_CONTRATISTA), CONTRATISTA from mdlo_gestion_alertas.vistas.all_seg_alertas_noreg A INNER JOIN df_integrantes_consultados I ON A.ID_CONTRATISTA = I.IDENTIFICACION """).persist(StorageLevel.MEMORY_AND_DISK)

# COMMAND ----------

df_alertados = df_alertados.withColumn('MARCA_ALERTADOS', fu.lit('ALERTADO_DIARI'))
display(df_alertados)

# COMMAND ----------

exportar_archivo(df_alertados,'Alertados_DIARI',formato)