# Databricks notebook source
# MAGIC %md 
# MAGIC <h1> NO EDITAR, POR FAVOR CLONARLO Y TRABAJAR EN SU PROPIO WORKSPACE <h/1>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Notebook Download
# MAGIC
# MAGIC
# MAGIC El cuaderno "download" es un script diseñado para ser ejecutado en un entorno Databricks, utilizando PySpark para procesar datos en paralelo. Su objetivo principal es descargar un conjunto de datos específico y guardarlo en formato Delta en una ubicación de salida determinada. El cuaderno utiliza varias funciones importadas desde otro cuaderno de Databricks, y sigue los siguientes pasos:
# MAGIC
# MAGIC Importa funciones desde otro cuaderno de Databricks ("/Users/jorge.sabogal@contraloria.gov.co/Open_Data/Functions").
# MAGIC
# MAGIC Define las rutas de entrada y salida de los archivos de datos.
# MAGIC
# MAGIC Configura widgets de entrada para capturar parámetros del usuario, como id_conjunto, ordenar, name, exportar, nw_d, limit y token.
# MAGIC
# MAGIC Obtiene los argumentos de entrada proporcionados por el usuario a través de los widgets.
# MAGIC
# MAGIC Importa paquetes adicionales necesarios para el procesamiento de datos.
# MAGIC
# MAGIC Define funciones auxiliares, como dateTime() y schema_from_metadata(metadatos).
# MAGIC
# MAGIC Define la función principal main() que realiza las siguientes tareas:
# MAGIC
# MAGIC a. Calcula el tamaño del conjunto de datos y el número de iteraciones (loops) necesarias para descargarlo por completo.
# MAGIC
# MAGIC b. Obtiene los metadatos del conjunto de datos, los nombres originales de los campos y los campos de selección.
# MAGIC
# MAGIC c. Crea un esquema a partir de los metadatos del conjunto de datos.
# MAGIC
# MAGIC d. Itera sobre las particiones del conjunto de datos, descargando cada partición en un DataFrame de PySpark, y luego une estos DataFrames en un único DataFrame final.
# MAGIC
# MAGIC e. Reparte el DataFrame final en un número específico de particiones.
# MAGIC
# MAGIC f. Guarda el DataFrame final en formato Delta en la ubicación de salida especificada.
# MAGIC
# MAGIC g. Imprime información sobre el tiempo de ejecución y el número de registros procesados.
# MAGIC
# MAGIC Ejecuta la función principal main().
# MAGIC
# MAGIC Este cuaderno permite a los usuarios descargar conjuntos de datos grandes de manera eficiente utilizando PySpark, y almacenarlos en un formato optimizado (Delta) para futuros análisis y procesamiento.
# MAGIC
# MAGIC 2023-08-23 --> Se ajusta MAIN con el fin de borrar los datos de UC-Plata y el catalogo de UnityCatalog
# MAGIC 2023-10-24 --> Se adiciona en la linea 22 del método PROCESO QUE PERMITE LA ESCRITURA Y DISPOSICIÓN EN UC-PLATA, la inclusión del encoding UTF 8.

# COMMAND ----------

# =============================================================================
# Importar paquetes necesarios
# =============================================================================
import os
import sys
import shutil
import re
import gc
import math
import time
import json
import requests
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.pandas as ks
from sodapy import Socrata
from delta.tables import DeltaTable
from datetime import datetime
from pyspark.sql.functions import length, max as spark_max, lit
from pyspark.sql.types import StringType, StructType, StructField
from pyspark.sql import SparkSession
from concurrent.futures import ThreadPoolExecutor

# COMMAND ----------

#dbutils.fs.rm("/mnt/_delta_log", True)

# COMMAND ----------

# =============================================================================
# Importar paquetes necesarios
# =============================================================================
ruta_entrada = "abfss://uc-plata@statesuiprocesados.dfs.core.windows.net/gpif/900514813/Datos_Abiertos"
ruta_desarrollo = ruta_entrada + "/SCRIPTS"
ruta_trabajo = ruta_entrada + "/OUTPUTS"

# COMMAND ----------

# =============================================================================
# Parámetros
# =============================================================================
dbutils.widgets.text("id_conjunto", "")
dbutils.widgets.text("ordenar", "")
dbutils.widgets.text("name", "")
dbutils.widgets.text("exportar", "")
dbutils.widgets.text("nw_d", "")
dbutils.widgets.text("limit", "")
dbutils.widgets.text("chunk", "")
dbutils.widgets.text("token", "")

# COMMAND ----------

# =============================================================================
# Argumentos de entrada
# =============================================================================
id_conjunto = dbutils.widgets.get("id_conjunto")
ordenar = dbutils.widgets.get("ordenar")
name = dbutils.widgets.get("name")
exportar = dbutils.widgets.get("exportar")
nw_d = dbutils.widgets.get("nw_d")
limit = int(dbutils.widgets.get("limit"))
chunk = int(dbutils.widgets.get("chunk"))
token = dbutils.widgets.get("token")

# COMMAND ----------

# =============================================================================
# Crear el cliente de Sodapy
# =============================================================================

def clientSodapy(appToken:str,domain:str = 'datos.gov.co',timeout:int = 500):
    client = Socrata(domain,appToken,timeout=timeout)
    return client

# COMMAND ----------

# =============================================================================
# Obtener fecha actual
# =============================================================================
def dateTime():
    date = datetime.now()
    return date.strftime('%Y-%m-%d %H:%M:%S')

# COMMAND ----------

# =============================================================================
# DOCUMENTAR
# =============================================================================

def metadata_set(set_id, app_token):
    url = f"https://www.datos.gov.co/api/views/{set_id}/columns"
    headers = {"X-App-Token": app_token}
    response = requests.get(url, headers=headers)
    desc_set = response.json()

    field = [x['fieldName'] if 'fieldName' in x else 'SIN METADATOS' for x in desc_set]
    name = [x['name'].replace(' ', '_') if 'name' in x else 'SIN METADATOS' for x in desc_set]
    data_type = [x['dataTypeName'] if 'dataTypeName' in x else 'SIN METADATOS' for x in desc_set]
    descripcion = [x['description'] if 'description' in x else 'SIN METADATOS' for x in desc_set]

    metadatos = []

    for f, n, dt, d in zip(field, name, data_type, descripcion):
        metadatos.append({'field': f, 'nombre_original': n, 'data_type': dt, 'descripcion': d})

    return metadatos, field, name

# COMMAND ----------

# =============================================================================
# DOCUMENTAR
# =============================================================================

from time import sleep
import requests

def query_da_offset(spark, fieldSelect, originNames, appToken, method, outPath, name, i, orderVar, setId, limit, dateTime, retries=40, delay=15, timeout=60):
    fieldSelect_str = ",".join(fieldSelect)
    offset = i * limit

    # Escapar los nombres de campo con espacios utilizando comillas dobles
    originNames_escaped = ['"' + orig_name + '"' if ' ' in orig_name else orig_name for orig_name in originNames]
    fieldSelect_escaped = ['"' + field_name + '"' if ' ' in field_name else field_name for field_name in fieldSelect]

    # Crear la consulta de la API utilizando los nombres de campo escapados
    query_url = f"https://www.datos.gov.co/resource/{setId}.json?$select={','.join(fieldSelect_escaped)}&$limit={limit}&$offset={offset}&$order={orderVar}"

    for attempt in range(retries):
        try:
            response = requests.get(query_url, headers={"X-App-Token": appToken}, timeout=timeout)
            response.raise_for_status()
            break
        except requests.exceptions.Timeout:
            if attempt < retries - 1:
                sleep(delay)
                continue
            else:
                raise ValueError("Timeout error: API didn't respond within the given time limit.")
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Error in API request: {e}")

    if response.status_code == 200:
        data = response.json()
        if data:
            pdf = pd.DataFrame(data)

            # Agregar columnas faltantes con valores nulos
            for orig_name in originNames:
                if orig_name not in pdf.columns:
                    #pdf[orig_name] = None
                    pdf[orig_name] = 'NO ENCONTRADO EN DATOS ABIERTOS'

            # Renombrar las columnas utilizando los nombres de campo originales
            new_columns = {old_col: new_col for old_col, new_col in zip(pdf.columns, originNames_escaped) if old_col in pdf.columns}
            #pdf.rename(columns=new_columns, inplace=True)
            pdf.rename(new_columns, inplace=True)
            pdf=pdf[originNames_escaped]

            pdf = pdf.astype(str)

            # Añadir la fecha actual al nombre de la carpeta
            current_date = datetime.now().strftime('%Y%m%d')
            folder_path = os.path.join(outPath, f"{name}")
            #folder_path = os.path.join(outPath, f"{name}_{current_date}")

            sdf = spark.createDataFrame(pdf)
            return sdf
        else:
            return None
    else:
        error_message = f"Error in API response: {response.status_code}"
        if response.text:
            error_message += f"\n{response.text}"
        raise ValueError(error_message)

# COMMAND ----------

# =============================================================================
# MÉTODO QUE PERMITE LAS CONSULTAS A LOS DIFERENTES FORMULARIOS
# =============================================================================

from time import sleep
import requests


def sizeSet(setId, app_token, limit, retries=100, delay=10, timeout=30):
    client = Socrata("www.datos.gov.co", app_token)
    query_url = f"https://www.datos.gov.co/resource/{setId}.json?$select=COUNT(*)"

    for attempt in range(retries):
        try:
            response = requests.get(query_url, headers={"X-App-Token": app_token}, timeout=timeout)
            response.raise_for_status()
            break
        except requests.exceptions.Timeout:
            if attempt < retries - 1:
                sleep(delay)
                continue
            else:
                raise ValueError("Timeout error: API didn't respond within the given time limit.")
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Error in API request: {e}")

    if response.status_code == 200:
        results = response.json()
        total_registros = int(results[0]['COUNT'])
        loops = int(total_registros / limit) + 1
        return total_registros, loops
    else:
        error_message = f"Error in API response: {response.status_code}"
        if response.text:
            error_message += f"\n{response.text}"
        raise ValueError(error_message)

# COMMAND ----------



# COMMAND ----------

# =============================================================================
# PROCESO QUE PERMITE LA ESCRITURA Y DISPOSICIÓN EN UC-PLATA
# =============================================================================

def process_chunk(chunk_start, spark, nombres_originales, campos_select, token, ordenar, id_conjunto, limit, date_time, delta_folder_path, total_loops):
    for i in range(chunk_start, min(chunk_start + chunk, total_loops)):
        print(f"Procesando loop {i + 1} de {total_loops}")
        df = query_da_offset(spark, fieldSelect=nombres_originales,
                             originNames=nombres_originales,
                             appToken=token,
                             method='delta',
                             outPath=ruta_trabajo,
                             name=name,
                             i=i,
                             orderVar=ordenar,
                             setId=id_conjunto,
                             limit=limit,
                             dateTime=date_time)

        if df is not None:
            ##df.write.format("delta").mode("append").save(delta_folder_path)
            df.write.format("delta").option("encoding", "UTF-8").mode("append").save(delta_folder_path)
            nombre_tabla = delta_folder_path.split("/")[-1]
            spark.sql(f"CREATE TABLE IF NOT EXISTS cd_gpif.`900514813`.{nombre_tabla} USING DELTA LOCATION '{delta_folder_path}' ")
            

        else:
            print(f"No se encontraron datos para guardar en el chunk {i}.")

# COMMAND ----------

# =============================================================================
# DEFINICIÓN DEL MAIN
# =============================================================================

from time import time
from datetime import datetime
import pandas as pd
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql import SparkSession



def dateTime():
    now = datetime.now()
    return now.strftime("%Y%m%d_%H%M%S")


def schema_from_metadata(metadatos):
    schema = StructType()
    for meta in metadatos:
        field_name = meta["nombre_original"]
        field_type = StringType()
        schema.add(StructField(field_name, field_type, nullable=True))
    return schema


def main():
    inicio = time()

    date_time = str(dateTime())

    total_registros, total_loops = sizeSet(setId=id_conjunto, app_token=token, limit=limit)

    metadatos, nombres_originales, campos_select = metadata_set(set_id=id_conjunto, app_token=token)

    schema = schema_from_metadata(metadatos)

    current_date = datetime.now().strftime('%Y%m%d')
    folder_path = os.path.join(ruta_trabajo, f"{name}")
    #folder_path = os.path.join(ruta_trabajo, f"{name}_{current_date}")
    delta_folder_path = folder_path
    #delta_folder_path = os.path.join(folder_path, "delta")
    nombre_tabla = delta_folder_path.split("/")[-1]
    nombre_tabla2=nombre_tabla.upper()
    spark.sql(f"DROP TABLE IF EXISTS cd_gpif.`900514813`.{nombre_tabla}")
    dbutils.fs.rm(f'abfss://uc-plata@statesuiprocesados.dfs.core.windows.net/gpif/900514813/Datos_Abiertos/OUTPUTS/{nombre_tabla2}', recurse=True)
    print(f"Procesando el conjunto de datos {name} ({id_conjunto}).")
    print(f"Total de registros: {total_registros}")
    print(f"Total de loops: {total_loops}")

    # Número de trabajadores (workers) en paralelo. Puedes ajustar este valor según tus necesidades.
    num_workers = 32

    with ThreadPoolExecutor(max_workers=num_workers) as executor:
        futures = []
        for i in range(0, total_loops, chunk):
            try:
                print(f"Procesando chunks {i + 1} hasta {min(i + chunk, total_loops)}...")
                future = executor.submit(process_chunk, i, spark, nombres_originales, campos_select, token, ordenar, id_conjunto, limit, date_time, delta_folder_path, total_loops)
                futures.append(future)
            except Exception as e:
                print(f"Error al procesar los chunks {i + 1} hasta {min(i + chunk, total_loops)}: {e}")
                continue

        for future in futures:
            future.result()

    final = time()

    print(f"La ejecución de la descarga del conjunto de datos {name} ({id_conjunto}), con ({total_registros}) registros, demoró {round((final - inicio) / 60, 1)} minutos.")

if __name__ == "__main__":
    main()