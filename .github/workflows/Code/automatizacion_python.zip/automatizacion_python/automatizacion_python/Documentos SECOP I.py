# Databricks notebook source
# MAGIC %md 
# MAGIC <h1> NO EDITAR, POR FAVOR CLONARLO Y TRABAJAR EN SU PROPIO WORKSPACE <h/1>

# COMMAND ----------

# MAGIC %pip install sodapy
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# =============================================================================
# Importar paquetes necesarios
# =============================================================================
import gc
import json
import requests
import pandas as pd
from pyspark.sql import SparkSession
from sodapy import Socrata
from datetime import datetime
from pyspark.sql.functions import length, max as spark_max, lit
from pyspark.sql.types import StringType, StructType, StructField
from pyspark.sql import SparkSession
import concurrent.futures
from time import time,sleep
from datetime import datetime

# COMMAND ----------

def clientSodapy(appToken:str,domain:str = 'datos.gov.co',timeout:int = 500):
    client = Socrata(domain,appToken,timeout=timeout)
    return client

# COMMAND ----------

def metadata_set(set_id, app_token):
    url = f"https://www.datos.gov.co/api/views/{set_id}/columns"
    headers = {"X-App-Token": app_token}
    response = requests.get(url, headers=headers)
    desc_set = response.json()

    field = [x['fieldName'] if 'fieldName' in x else 'SIN METADATOS' for x in desc_set]
    name = [x['name'].replace(' ', '_') if 'name' in x else 'SIN METADATOS' for x in desc_set]
    data_type = [x['dataTypeName'] if 'dataTypeName' in x else 'SIN METADATOS' for x in desc_set]
    descripcion = [x['description'] if 'description' in x else 'SIN METADATOS' for x in desc_set]

    metadatos = []

    for f, n, dt, d in zip(field, name, data_type, descripcion):
        metadatos.append({'field': f, 'nombre_original': n, 'data_type': dt, 'descripcion': d})

    return metadatos, field, name

# COMMAND ----------

def sizeSet(setId, app_token, limit, retries=100, delay=10, timeout=30):
    client = Socrata("www.datos.gov.co", app_token)
    query_url = f"https://www.datos.gov.co/resource/{setId}.json?$select=COUNT(*)"

    for attempt in range(retries):
        try:
            response = requests.get(query_url, headers={"X-App-Token": app_token}, timeout=timeout)
            response.raise_for_status()
            break
        except requests.exceptions.Timeout:
            if attempt < retries - 1:
                sleep(delay)
                continue
            else:
                raise ValueError("Timeout error: API didn't respond within the given time limit.")
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Error in API request: {e}")

    if response.status_code == 200:
        results = response.json()
        total_registros = int(results[0]['COUNT'])
        loops = int(total_registros / limit) + 1
        return total_registros, loops
    else:
        error_message = f"Error in API response: {response.status_code}"
        if response.text:
            error_message += f"\n{response.text}"
        raise ValueError(error_message)

# COMMAND ----------

def pre_process_request(id_conjunto,token,limit,name):
  total_registros, total_loops = sizeSet(id_conjunto, token,limit)
  metadatos, nombres_originales, campos_select = metadata_set(id_conjunto, token)
  fieldSelect=[field for field in nombres_originales if field not in ['extension','tama_o','titulo','usuario_creacion','codigo_entidad','usuario_ultima_modificacion','version','tipo','url_descarga_documento','tamanno_archivo','extensi_n','nombrearchivo','fecha_creacion']]
  originNames=nombres_originales
  print(f'Se consultarán: {total_registros} registros en {total_loops} loops.')
  schema=' STRING,'.join(fieldSelect)+' STRING'
  schema+=',url_descarga_documento MAP<STRING,STRING>'
  query=f"""DROP TABLE  IF EXISTS mdlo_contractual.staging.{name}"""
  spark.sql(query)
  print('Se ha creado la tabla con el esquema apropiado')
  query=f"""CREATE TABLE mdlo_contractual.staging.{name} ({schema})"""
  spark.sql(query)
  return total_loops,fieldSelect

# COMMAND ----------

# DBTITLE 1,Parámetros descarga archivos SECOP I
token='cQ0AKakQ7Q3EjB5zwVu63MWJl'
id_conjunto='ps88-5e3v'
limit=600000
name='s1_metadata'
ordenar='identificador'
retries=10
delay=20
total_loops,fieldSelect=pre_process_request(id_conjunto,token,limit,name)
fieldSelect_escaped = ['"' + field_name + '"' if ' ' in field_name else field_name for field_name in fieldSelect]

# COMMAND ----------

def request_api(loop):
  if loop<50:
    timeout=90
  else:
    timeout=120
  offset=loop*limit
# Crear la consulta de la API utilizando los nombres de campo escapados
  query_url = f"https://www.datos.gov.co/resource/{id_conjunto}.json?$select={','.join(fieldSelect_escaped)}&$limit={limit}&$offset={offset}&$order={ordenar}"
  # print(query_url)
  for attempt in range(retries):
    print(f"Procesando loop {loop} ............. Attempt: {attempt}")#,end="\r" 
    try:
      response = requests.get(query_url, headers={"X-App-Token": token}, timeout=timeout)
      response.raise_for_status()
      break
    except requests.exceptions.Timeout:
      print(f"Timeout loop {loop}")#end="\r"
      if attempt < retries - 1:
        sleep(delay)
        continue
      else:
        raise ValueError("Timeout error: API didn't respond within the given time limit.")
    except requests.exceptions.RequestException as e:
      raise ValueError(f"Error in API request: {e}")
  if response.status_code == 200:
    print(f"Cargando data loop {loop} .....................................")
    data = spark.createDataFrame(response.json())
    print(f"Escribiendo data loop {loop} .....................................")#,end="\r"
    data.write.format("delta").mode("append").saveAsTable(f"mdlo_contractual.testing.{name}")

# COMMAND ----------

with concurrent.futures.ThreadPoolExecutor() as executor:
  results = executor.map(request_api, list(range(0,total_loops))) # map takes the  function and iterables
  for result in results: # loop through results
    pass

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE mdlo_contractual.insumos.documentos_secop1 AS (
# MAGIC WITH PRE AS (select numero_de_constancia AS ID_CONTRATO,fecha_ultima_modificacion AS FECHA,COLLECT_SET(mdlo_contractual.reporting.limpieza_texto_sencilla(coalesce(DESCRIPCION,palabras_clave))) AS DOCUMENTOS_ULTIMA_FECHA,ROW_NUMBER()OVER(PARTITION BY numero_de_constancia ORDER BY fecha_ultima_modificacion DESC) row
# MAGIC from mdlo_contractual.testing.s1_metadata
# MAGIC GROUP BY ID_CONTRATO,fecha_ultima_modificacion),
# MAGIC ULTIMOS_VALORES AS (
# MAGIC SELECT ID_CONTRATO,FECHA AS ULTIMA_FECHA,DOCUMENTOS_ULTIMA_FECHA
# MAGIC FROM PRE
# MAGIC WHERE row=1),
# MAGIC TOTALES AS (
# MAGIC SELECT numero_de_constancia AS ID_CONTRATO,COLLECT_SET(mdlo_contractual.reporting.limpieza_texto_sencilla(coalesce(DESCRIPCION,palabras_clave))) AS DOCUMENTOS
# MAGIC from mdlo_contractual.testing.s1_metadata
# MAGIC GROUP BY numero_de_constancia)
# MAGIC SELECT T.*,U.* EXCEPT(ID_CONTRATO),CASE 
# MAGIC WHEN CONCAT_WS('|',U.DOCUMENTOS_ULTIMA_FECHA) RLIKE r'LIQUIDACI' THEN 'LIQUIDADO'   
# MAGIC WHEN CONCAT_WS('|',U.DOCUMENTOS_ULTIMA_FECHA) RLIKE r'14 ADICION|OTROSI|OTRO SI|OTRO S|PRORROG' THEN 'INDEFINIDO - ADICION' 
# MAGIC WHEN CONCAT_WS('|',U.DOCUMENTOS_ULTIMA_FECHA) RLIKE r'13 CONTRATO|CONTRATO|ADJUDICACI' THEN 'INDEFINIDO - ADJUDICADO' 
# MAGIC WHEN CONCAT_WS('|',U.DOCUMENTOS_ULTIMA_FECHA) RLIKE r'SUSPENCION|SUSPENSION' THEN 'INDEFINIDO - SUSPENSION' 
# MAGIC ELSE 'INDEFINIDO' END AS ESTADO_POR_DOCUMENTOS,UN.NUMERO_CONTRATOS,UN.LISTA_IDS
# MAGIC FROM ULTIMOS_VALORES U --ON M.ID_CONTRATO=U.ID_CONTRATO
# MAGIC LEFT JOIN TOTALES T ON U.ID_CONTRATO=T.ID_CONTRATO
# MAGIC LEFT JOIN mdlo_contractual.testing.unicidad_id_descarga UN ON UN.ID_DESCARGA = U.ID_CONTRATO
# MAGIC )--LEFT JOIN mdlo_contractual.testing.unicidad_id_descarga U ON U.ID_DESCARGA = CONCAT_WS('-',SLICE(SPLIT(C.ID_CONTRATO,'-'),1,3)) 