# Databricks notebook source
# MAGIC %md 
# MAGIC <h1> NO EDITAR, POR FAVOR CLONARLO Y TRABAJAR EN SU PROPIO WORKSPACE <h/1>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Notebook exe
# MAGIC En este código, se implementan buenas prácticas de programación, como agregar comentarios, usar nombres de variables descriptivos y organizar el código en secciones lógicas. A continuación, se presenta una descripción general del código:
# MAGIC
# MAGIC Se importan los paquetes necesarios.
# MAGIC
# MAGIC Se define la ruta de entrada y la ruta de escritura para los archivos de datos.
# MAGIC
# MAGIC Se lee un archivo de Excel que contiene información sobre varios conjuntos de datos en un DataFrame de Koalas llamado listado_da.
# MAGIC
# MAGIC Se convierte el DataFrame de Koalas listado_da a un DataFrame de pandas llamado listado_da_pd.
# MAGIC
# MAGIC Se realiza un proceso en el que se itera sobre cada fila del DataFrame listado_da_pd. Para cada fila:
# MAGIC
# MAGIC a. Se extraen los valores de las columnas relevantes.
# MAGIC
# MAGIC b. Se crea un diccionario llamado arguments que contiene estos valores.
# MAGIC
# MAGIC c. Se llama a un cuaderno de Databricks llamado "/Users/jorge.sabogal@contraloria.gov.co/Open_Data/Download" con estos argumentos.
# MAGIC
# MAGIC Se imprime un mensaje para indicar que el proceso ha finalizado.
# MAGIC
# MAGIC Ten en cuenta que este código está diseñado para ser ejecutado en un entorno Databricks, utilizando PySpark y Koalas para procesar datos en paralelo.

# COMMAND ----------

# =============================================================================
# Importar paquetes necesarios
# =============================================================================
from pyspark.sql import SparkSession
from pyspark.sql.types import StringType
from pyspark.sql.functions import col
import pyspark.pandas as ks
import os
import requests
import json
import pandas as pd
import concurrent.futures


# COMMAND ----------

# =============================================================================
# Definir rutas de entrada y salida de los archivos de datos
# =============================================================================
ruta_entrada = "abfss://uc-plata@statesuiprocesados.dfs.core.windows.net/gpif/900514813/Datos_Abiertos"
ruta_escritura = ruta_entrada


# COMMAND ----------

# =============================================================================
# DOCUMENTAR
# =============================================================================

dbutils.fs.ls("abfss://plata@statesuiprocesados.dfs.core.windows.net/gpif/GPIF_CCE/ArchivosConfiguracion")

# COMMAND ----------

#dbutils.fs.rm("/mnt/_delta_log", True)

# COMMAND ----------

# =============================================================================
# DOCUMENTAR
# =============================================================================

ruta_config = "abfss://plata@statesuiprocesados.dfs.core.windows.net/gpif/GPIF_CCE/ArchivosConfiguracion"
#ruta_config = "/mnt/general/jasabogal/prueba/Datos_abiertos/config_datasets/"

# COMMAND ----------

# =============================================================================
# Leer archivo Excel en un DataFrame de Koalas
# =============================================================================
# Se lee el archivo Excel 'Configuracion_DA.xlsx' que contiene información sobre
# varios conjuntos de datos, y se guarda en un DataFrame de Koalas llamado 'listado_da'.

listado_da = ks.read_excel(os.path.join(ruta_config,"Configuracion_DA.xlsx"))


# COMMAND ----------

# =============================================================================
# Convertir el DataFrame de Koalas a un DataFrame de pandas
# =============================================================================
# Se convierte el DataFrame de Koalas 'listado_da' a un DataFrame de pandas llamado 'listado_da_pd'.
listado_da_pd = listado_da.to_pandas()

# COMMAND ----------

# =============================================================================
# DOCUMENTAR
# Conexión NoteBook de descarga
# =============================================================================

#ruta_download = "/Users/jorge.sabogal@contraloria.gov.co/Open_Data/Download"
# ruta_download = "/Shared/Produccion/Open_Data_20230713/Download"
ruta_download= '/Workspace/Shared/produccion/MDLO_CONTRACTUAL/Actualización Modelo/Open_Data_20230713/Download'

# COMMAND ----------

# =============================================================================
# Función para ejecutar un notebook y manejar excepciones
# =============================================================================


def run_notebook(arguments):
    try:
        dbutils.notebook.run(ruta_download, 0, arguments)
    except (WorkflowException, NotebookExecutionException) as e:
        print(f"Error al ejecutar el notebook con argumentos {arguments}: {e}")
        return False
    return True


# COMMAND ----------

# =============================================================================
# Proceso principal: iterar sobre las filas del DataFrame y ejecutar un cuaderno de Databricks
# =============================================================================
# Se itera sobre cada fila del DataFrame 'listado_da_pd'. Para cada fila:
# - Se extraen los valores de las columnas relevantes.
# - Se crea un diccionario llamado 'arguments' que contiene estos valores.
# - Se llama a un cuaderno de Databricks llamado "/Users/jorge.sabogal@contraloria.gov.co/Open_Data/Download" con estos argumentos.
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    # Crear una lista para almacenar objetos Future
    futures = []

    for _, row in listado_da_pd.iterrows():
        id_conjunto = row['id_conjunto']
        ordenar = row['ordenar']
        name = row['name']
        exportar = row['exportar']
        nw_d = row['nw_d']
        limit = row['limit']
        nw_e = row['nw_e']
        chunk = row['chunk']
        token = row['token']

        # Pasa los argumentos como variables a otro cuaderno de Databricks
        arguments = {
            "id_conjunto": id_conjunto,
            "ordenar": ordenar,
            "name": name,
            "exportar": exportar,
            "nw_d": nw_d,
            "limit": limit,
            "chunk": chunk,
            "token": token
        }

        # Ejecuta el cuaderno de Databricks llamado 'Download' en la ruta especificada en paralelo
        futures.append(executor.submit(run_notebook, arguments))

    # Esperar a que todos los notebooks se hayan ejecutado
    concurrent.futures.wait(futures)

    # Verificar si hubo algún error en la ejecución de los notebooks
    errors = [future.result() for future in futures if not future.result()]

print(f'Finalizó el proceso con {len(errors)} errores')