# Databricks notebook source
# MAGIC %md 
# MAGIC <h1> NO EDITAR, POR FAVOR CLONARLO Y TRABAJAR EN SU PROPIO WORKSPACE <h/1>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Libraries
# MAGIC

# COMMAND ----------

import sys
import os
# Agrega la ruta de la carpeta Funciones al path del sistema
sys.path.insert(1, os.path.join(r'/Workspace/Shared/produccion/MDLO_CONTRACTUAL', "Modules"))
from datetime import date
from pyspark.sql.types import *
from pyspark.sql.functions import approxCountDistinct,regexp_replace,lit,col,create_map,pandas_udf,udf,when,concat
from itertools import chain
from pyspark import StorageLevel
import cleaning_functions_DIARI as cf
fecha_actual=str(date.today())
anio_actual=date.today().year

# COMMAND ----------

# dbutils.widgets.dropdown("TIPO CARGUE", "DELTA", ["DELTA", "TOTAL"])
tipo_cargue = dbutils.widgets.get("TIPO CARGUE")
tipo_cargue

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cargue a staging (ORI en .168)

# COMMAND ----------

# DBTITLE 1,Primer cargue en staging de datos abiertos
if tipo_cargue=='TOTAL':
    query="""CREATE OR REPLACE TABLE mdlo_contractual.staging.secop2 AS
    select A.*
    from cd_gpif.`900514813`.S2_CONT A
    WHERE A.estado_contrato   NOT IN ('Borrador','En aprobación','enviado Proveedor')"""
    spark.sql(query)

# COMMAND ----------

# DBTITLE 1,Delta cargue en staging de datos abiertos
if tipo_cargue=='DELTA':
    query=f"""
        select
        A.nombre_entidad as nombre_entidad,
        A.nit_entidad as nit_entidad,
        A.departamento as departamento,
        A.ciudad as ciudad,
        A.localizaci_n as localizaci_n,
        A.orden as orden,
        A.sector as sector,
        A.rama as rama,
        A.entidad_centralizada as entidad_centralizada,
        A.proceso_de_compra as proceso_de_compra,
        A.id_contrato as id_contrato,
        A.referencia_del_contrato as referencia_del_contrato,
        A.estado_contrato as estado_contrato,
        A.codigo_de_categoria_principal as codigo_de_categoria_principal,
        A.tipo_de_contrato as tipo_de_contrato,
        A.modalidad_de_contratacion as modalidad_de_contratacion,
        A.justificacion_modalidad_de as justificacion_modalidad_de,
        A.fecha_de_firma as fecha_de_firma,
        A.fecha_de_inicio_del_contrato as fecha_de_inicio_del_contrato,
        A.fecha_de_fin_del_contrato as fecha_de_fin_del_contrato,
        A.fecha_de_inicio_de_ejecucion as fecha_de_inicio_de_ejecucion,
        A.fecha_de_fin_de_ejecucion as fecha_de_fin_de_ejecucion,
        A.condiciones_de_entrega as condiciones_de_entrega,
        A.tipodocproveedor as tipodocproveedor,
        A.documento_proveedor as documento_proveedor,
        A.proveedor_adjudicado as proveedor_adjudicado,
        A.es_grupo as es_grupo,
        A.es_pyme as es_pyme,
        A.habilita_pago_adelantado as habilita_pago_adelantado,
        A.liquidaci_n as liquidaci_n,
        A.obligaci_n_ambiental as obligaci_n_ambiental,
        A.obligaciones_postconsumo as obligaciones_postconsumo,
        A.reversion as reversion,
        A.valor_del_contrato as valor_del_contrato,
        A.valor_de_pago_adelantado as valor_de_pago_adelantado,
        A.valor_facturado as valor_facturado,
        A.valor_pendiente_de_pago as valor_pendiente_de_pago,
        A.valor_pagado as valor_pagado,
        A.valor_amortizado as valor_amortizado,
        A.valor_pendiente_de as valor_pendiente_de,
        A.valor_pendiente_de_ejecucion as valor_pendiente_de_ejecucion,
        A.estado_bpin as estado_bpin,
        A.c_digo_bpin as c_digo_bpin,
        A.anno_bpin as anno_bpin,
        A.saldo_cdp as saldo_cdp,
        A.saldo_vigencia as saldo_vigencia,
        A.espostconflicto as espostconflicto,
        A.urlproceso as urlproceso,
        A.destino_gasto as destino_gasto,
        A.origen_de_los_recursos as origen_de_los_recursos,
        A.dias_adicionados as dias_adicionados,
        A.puntos_del_acuerdo as puntos_del_acuerdo,
        A.pilares_del_acuerdo as pilares_del_acuerdo,
        A.nombre_representante_legal as nombre_representante_legal,
        A.nacionalidad_representante_legal as nacionalidad_representante_legal,
        A.tipo_de_identificaci_n_representante_legal as tipo_de_identificaci_n_representante_legal,
        A.identificaci_n_representante_legal as identificaci_n_representante_legal,
        A.g_nero_representante_legal as g_nero_representante_legal,
        A.presupuesto_general_de_la_nacion_pgn as presupuesto_general_de_la_nacion_pgn,
        A.sistema_general_de_participaciones as sistema_general_de_participaciones,
        A.sistema_general_de_regal_as as sistema_general_de_regal_as,
        A.recursos_propios_alcald_as_gobernaciones_y_resguardos_ind_genas_ as recursos_propios_alcald_as_gobernaciones_y_resguardos_ind_genas_,
        A.recursos_de_credito as recursos_de_credito,
        A.recursos_propios as recursos_propios,
        A.ultima_actualizacion as ultima_actualizacion,
        A.codigo_entidad as codigo_entidad,
        A.fecha_inicio_liquidacion as fecha_inicio_liquidacion,
        A.fecha_fin_liquidacion as fecha_fin_liquidacion,
        A.codigo_proveedor as codigo_proveedor,
        A.objeto_del_contrato as descripcion_del_proceso
    from cd_gpif.`900514813`.S2_CONT A
    LEFT JOIN mdlo_contractual.staging.secop2 B ON A.id_contrato = B.id_contrato
    WHERE B.id_contrato IS NULL
    AND A.estado_contrato   NOT IN ('Borrador','En aprobación','enviado Proveedor')
    """
    row_count = spark.sql(f"SELECT COUNT(1) FROM mdlo_contractual.staging.secop2").collect()[0][0]
    print("Original number of rows in the table staging SECOP II:", row_count)

    df=spark.sql(query)#.persist(StorageLevel.MEMORY_AND_DISK)
    print("Number of rows new to append to staging SECOP II:",df.count())

    df.write.mode("append").saveAsTable('mdlo_contractual.staging.secop2')
    row_count = spark.sql(f"SELECT COUNT(1) FROM mdlo_contractual.staging.secop2").collect()[0][0]
    print("Current number of rows in the table staging SECOP II:", row_count)
    #df.unpersist()

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE mdlo_contractual.staging.origen_recursos_secop2 AS(
# MAGIC WITH PRE AS (
# MAGIC SELECT id_contrato AS ID_CONTRATO, 'PGN' AS ORIGEN_RECURSOS, CAST(presupuesto_general_de_la_nacion_pgn AS BIGINT) AS VALOR_DISTRIBUIDO_RECURSOS,c_digo_bpin AS CODIGO_BPIN
# MAGIC FROM mdlo_contractual.staging.secop2
# MAGIC WHERE CAST(presupuesto_general_de_la_nacion_pgn AS BIGINT)!=0
# MAGIC UNION ALL
# MAGIC SELECT id_contrato AS ID_CONTRATO, 'SGP' AS ORIGEN_RECURSOS, CAST(sistema_general_de_participaciones AS BIGINT) AS VALOR_DISTRIBUIDO_RECURSOS,c_digo_bpin AS CODIGO_BPIN
# MAGIC FROM mdlo_contractual.staging.secop2
# MAGIC WHERE CAST(sistema_general_de_participaciones AS BIGINT)!=0
# MAGIC UNION ALL
# MAGIC SELECT id_contrato AS ID_CONTRATO, 'SGR' AS ORIGEN_RECURSOS, CAST(sistema_general_de_regal_as AS BIGINT) AS VALOR_DISTRIBUIDO_RECURSOS,c_digo_bpin AS CODIGO_BPIN
# MAGIC FROM mdlo_contractual.staging.secop2
# MAGIC WHERE CAST(sistema_general_de_regal_as AS BIGINT)!=0
# MAGIC UNION ALL
# MAGIC SELECT id_contrato AS ID_CONTRATO, 'RECURSOS PROPIOS (ALCALDIAS GOBERNACIONES Y RESGUARDOS INDIGENAS)' AS ORIGEN_RECURSOS, CAST(recursos_propios_alcald_as_gobernaciones_y_resguardos_ind_genas_ AS BIGINT) AS VALOR_DISTRIBUIDO_RECURSOS,c_digo_bpin AS CODIGO_BPIN
# MAGIC FROM mdlo_contractual.staging.secop2
# MAGIC WHERE CAST(recursos_propios_alcald_as_gobernaciones_y_resguardos_ind_genas_ AS BIGINT)!=0
# MAGIC UNION ALL
# MAGIC SELECT id_contrato AS ID_CONTRATO, 'RECURSOS DE CREDITO' AS ORIGEN_RECURSOS, CAST(recursos_de_credito AS BIGINT) AS VALOR_DISTRIBUIDO_RECURSOS,c_digo_bpin AS CODIGO_BPIN
# MAGIC FROM mdlo_contractual.staging.secop2
# MAGIC WHERE CAST(recursos_de_credito AS BIGINT)!=0
# MAGIC UNION ALL
# MAGIC SELECT id_contrato AS ID_CONTRATO, 'RECURSOS PROPIOS' AS ORIGEN_RECURSOS, CAST(recursos_propios AS BIGINT) AS VALOR_DISTRIBUIDO_RECURSOS,c_digo_bpin AS CODIGO_BPIN
# MAGIC FROM mdlo_contractual.staging.secop2
# MAGIC WHERE CAST(recursos_propios AS BIGINT)!=0
# MAGIC )
# MAGIC SELECT ID_CONTRATO, 
# MAGIC CONCAT_WS(' | ',COLLECT_SET(ORIGEN_RECURSOS)) AS ORIGEN_RECURSOS,
# MAGIC CONCAT_WS(' | ',COLLECT_SET(VALOR_DISTRIBUIDO_RECURSOS)) AS VALOR_DISTRIBUIDO_RECURSOS, 
# MAGIC CONCAT_WS(' | ',COLLECT_SET(CODIGO_BPIN)) AS CODIGO_BPIN FROM PRE GROUP BY ID_CONTRATO
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cargue de staging a cleansed (STG in .168)
# MAGIC <ol>
# MAGIC <li> Tomar contratos del esquema staging que no están cleansed y cuyo id_adjudicacion no sea nulo
# MAGIC <li> Fundir con la tabla s1_origen_recursos para sacar información del origen de recursos
# MAGIC <li> La tabla de origen de recursos necesita reclasificación y seleccionar el primero por id_adjudicación de acuerdo al valor.
# MAGIC <li> Duración lo calcula usando DATEDIFF entre fecha inicio y fin de ejecución.
# MAGIC <li> Extraer URL del JSON usando get_json_object.
# MAGIC <li> Colocar en mayúsculas el valor de múltiples campos.
# MAGIC <li> Corrección municipio ejecución, entidad y nombre de entidad está jodido. Planear generalidad y corregirlo. <br>
# MAGIC Crea campo PERSONERIA, CONCEJO, ALCALDIA, GOBERNACIÓN <br>
# MAGIC Mejor tomar campo DEPARTAMENTO_ENTIDAD,MUNICIPIO_ENTIDAD y asociarlo a DIVIPOLA
# MAGIC <li> Derivar DEPARTAMENTO_EJECUCION y MUNICIPIO_EJECUCION para 3 diferentes opciones con un split(";")
# MAGIC <li> Limpieza IDENTIFICACIÓN CONTRATISTA
# MAGIC <li> Limpieza NOMBRE_CONTRATISTA/NOMBRE_ENTIDAD son caracteres especiales y tildes
# MAGIC <li> El objeto se toma el más largo entre detalle_del_objeto_a_contratar y objeto_del_contrato_a_la_firma. Limpiar caracteres especiales y tildes
# MAGIC <li> Extraer ID_SEGMENTO y NOMBRE_SEGMENTO a partir de cruce con la tabla BIENES Y SERVICIOS.
# MAGIC <li> Corrección de campos cuantia_contrato y valor_contrato_con_adiciones. Revisar los que tienen moneda = 'Dolares (USD)'
# MAGIC <li> Extraer plazo de ejecución en días usando rango_ejec_del_contrato y plazo_de_ejec_del_contrato.
# MAGIC <li> Columna MARCA_CONSORCIO_UT sale de mirar NOMBRE_CONTRATISTA.
# MAGIC </ol> 

# COMMAND ----------

# DBTITLE 1,Primer cargue de staging a cleansed
if tipo_cargue=='TOTAL':
    query=f"""
    CREATE OR REPLACE TABLE mdlo_contractual.cleansed.secop2 AS
    SELECT 'SECOP II' AS FUENTE,B.id_contrato AS ID_CONTRATO,mdlo_contractual.reporting.limpieza_dv_sencilla(mdlo_contractual.reporting.limpieza_id_sencilla(nit_entidad)) AS NIT_ENTIDAD, mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(nombre_entidad)) AS NOMBRE_ENTIDAD,UPPER(departamento) AS DEPARTAMENTO_SV,UPPER(SPLIT(localizaci_n,',')[SIZE(SPLIT(localizaci_n,','))-1]) AS MUNICIPIO_SV,UPPER(tipodocproveedor) AS TIPO_ID_CONTRATISTA,mdlo_contractual.reporting.limpieza_dv_sencilla(mdlo_contractual.reporting.limpieza_id_sencilla(documento_proveedor)) AS IDENTIFICACION_CONTRATISTA, mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(proveedor_adjudicado)) AS NOMBRE_CONTRATISTA,fecha_de_firma AS FECHA_SUSCRIPCION,referencia_del_contrato AS NUMERO_CONTRATO,valor_del_contrato AS VALOR_TOTAL_CONTRATO, mdlo_contractual.reporting.LIMPIEZA_TEXTO_SENCILLA(descripcion_del_proceso) AS OBJETO_CONTRATO,YEAR(CAST (fecha_de_firma AS DATE)) AS ANO_SUSCRIPCION,'NO DEFINIDO' AS CAUSAL_CONTRATACION_DIRECTA,0 AS VALOR_INICIAL_CONTRATO,'NO DEFINIDO' AS DEPARTAMENTO_EJECUCION_1,fecha_de_inicio_del_contrato AS FECHA_INICIO,fecha_de_fin_del_contrato AS FECHA_FIN,
    mdlo_contractual.reporting.clasificacion_contratistas(mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(nombre_entidad))) AS CLASIFICACION_ENTIDAD_STD,
    mdlo_contractual.reporting.clasificacion_contratistas(mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(proveedor_adjudicado))) AS CLASIFICACION_CONTRATISTA_STD,
    --CASE WHEN mdlo_contractual.reporting.limpieza_texto_sencilla(proveedor_adjudicado) RLIKE r'CONSORCIO|\\bU.?T.?\\b|--UNI.?NTEMPORAL|\\bCS\\b' THEN 1 ELSE 0 END AS MARCA_CONSORCIO_UT,
    UPPER(destino_gasto) AS TIPO_GASTO,CASE 
    WHEN UPPER(modalidad_de_contratacion) LIKE '%CONCURSO%' THEN 'CONCURSO DE MERITOS'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%CONTRATACI%DIRECTA%' THEN 'CONTRATACION DIRECTA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%M_NIMA%CUANT%' THEN 'MINIMA CUANTIA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%LICITAC%' THEN 'LICITACION PUBLICA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%ESPECIAL%' THEN 'OTRAS FORMAS DE CONTRATACION DIRECTA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%SELECCI%ABREVIADA%' THEN 'SELECCION ABREVIADA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%CONVENIO%' THEN 'OTRAS FORMAS DE CONTRATACION DIRECTA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%ENAJENAC%' THEN 'ENAJENACION'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%NO%DEFINIDO%' THEN 'OTRO' 
    WHEN UPPER(modalidad_de_contratacion) LIKE '%INVITACI%' 
    OR UPPER(modalidad_de_contratacion) LIKE '%PRESENTAR%INTER%' THEN 'PRESENTACION OFERTAS'
    ELSE UPPER(modalidad_de_contratacion) END AS MODALIDAD,'NO DEFINIDO' AS MUNICIPIO_EJECUCION_1,'NO DEFINIDO' AS NIVEL_ENTIDAD,'NO DEFINIDO' AS NUMERO_CONSTANCIA,
    COALESCE(OR.ORIGEN_RECURSOS,mdlo_contractual.reporting.limpieza_texto_sencilla(origen_de_los_recursos)) AS ORIGEN_RECURSOS,OR.VALOR_DISTRIBUIDO_RECURSOS,
    'NO DEFINIDO' AS PLAZO_EJEC_CONTRATO,'NO DEFINIDO' AS REGIMEN_DE_CONTRATACION,CASE WHEN urlproceso LIKE '%_url_%' THEN get_json_object(urlproceso,'$.url' ) ELSE urlproceso END AS ENLACE, mdlo_contractual.reporting.limpieza_texto_sencilla(B.SECTOR) AS SECTOR,
    0 AS VALOR_TOTAL_ADICIONES,c_digo_bpin AS CODIGO_BPIN,espostconflicto AS ESPOSTCONFLICTO,UPPER(estado_contrato) AS ESTADO_CONTRATO,ultima_actualizacion AS FECHA_ACTUALIZACION,PB.ID_SEGMENTO,UPPER(PB.NOMBRE_SEGMENTO) AS NOMBRE_SEGMENTO,PB.ID_FAMILIA,UPPER(PB.NOMBRE_FAMILIA) AS NOMBRE_FAMILIA,PB.ID_CLASE,UPPER(PB.NOMBRE_CLASE)AS NOMBRE_CLASE,PB.ID_GRUPO,UPPER(PB.NOMBRE_GRUPO) AS NOMBRE_GRUPO,CAST(PB.ID_PRODUCTO AS BIGINT) AS ID_PRODUCTO,UPPER(PB.NOMBRE_PRODUCTO) AS NOMBRE_PRODUCTO,proceso_de_compra AS NUMERO_PROCESO,tipo_de_contrato AS TIPO_DE_CONTRATO,'NO DEFINIDO' AS COMPROMISO_PRESUPUESTAL,DATEDIFF(fecha_de_fin_del_contrato,COALESCE(CAST(fecha_de_inicio_de_ejecucion AS DATE),CAST(fecha_de_inicio_del_contrato AS DATE),CAST(fecha_de_firma AS DATE))) AS DURACION_CONTRATO,UPPER(tipo_de_identificaci_n_representante_legal) AS TIPO_ID_REP_LEGAL,TRIM(REGEXP_REPLACE(identificaci_n_representante_legal,r'[^0-9]' ,'')) AS IDENTIFICACION_REP_LEGAL, mdlo_contractual.reporting.LIMPIEZA_TEXTO_SENCILLA(nombre_representante_legal) AS NOMBRE_REP_LEGAL,orden AS ORDEN_ENTIDAD,valor_de_pago_adelantado AS VALOR_ANTICIPO,valor_facturado AS VALOR_FACTURADO,valor_pagado AS VALOR_PAGADO,'NO DEFINIDO' AS PROPONENTES_SELECCIONADOS,dias_adicionados AS TIEMPO_ADICIONES_DIAS,liquidaci_n AS LIQUIDACION,anno_bpin AS ANNO_BPIN,estado_bpin AS ESTADO_BPIN,valor_amortizado AS VALOR_AMORTIZADO,reversion AS REVERSION,es_grupo AS ES_GRUPO,fecha_de_fin_de_ejecucion AS FECHA_FIN_EJECUCION,fecha_de_inicio_de_ejecucion AS FECHA_INICIO_EJECUCION,'{fecha_actual}' AS FECHA_CARGA_UA
    FROM mdlo_contractual.staging.secop2 B
    LEFT JOIN mdlo_contractual.staging.origen_recursos_secop2 OR ON OR.ID_CONTRATO = B.ID_CONTRATO
    LEFT JOIN mdlo_contractual.insumos.bienes_servicios_secop PB ON PB.ID_PRODUCTO=RIGHT(codigo_de_categoria_principal,8)
    WHERE B.estado_contrato NOT IN ('En aprobación','Borrador','enviado Proveedor','Cancelado')
    """
    spark.sql(query)
    df = spark.sql(f"SELECT * FROM mdlo_contractual.cleansed.secop2").persist(StorageLevel.MEMORY_AND_DISK)

# COMMAND ----------

# DBTITLE 1,Delta cargue Staging a Cleansed
if tipo_cargue=='DELTA':
    query=f"""
    WITH PRE_SUJETOS_CONTROL AS (
        SELECT NIT,CONTRALORIA_DELEGADA,SECTOR,SUBSECTOR,row_number() OVER (PARTITION BY NIT ORDER BY FECHA_RESOLUCION DESC) row 
        FROM mdlo_contractual.insumos.sujetos_control)
        SELECT 'SECOP II' AS FUENTE,id_contrato AS ID_CONTRATO,nit_entidad AS NIT_ENTIDAD,nombre_entidad AS NOMBRE_ENTIDAD,departamento AS DEPARTAMENTO_SV,SPLIT(localizaci_n,',')[SIZE(SPLIT(localizaci_n,','))-1] AS MUNICIPIO_SV,UPPER(tipodocproveedor) AS TIPO_ID_CONTRATISTA,documento_proveedor AS IDENTIFICACION_CONTRATISTA,proveedor_adjudicado AS NOMBRE_CONTRATISTA,fecha_de_firma AS FECHA_SUSCRIPCION,referencia_del_contrato AS NUMERO_CONTRATO,valor_del_contrato AS VALOR_TOTAL_CONTRATO,descripcion_del_proceso AS OBJETO_CONTRATO,YEAR(CAST (fecha_de_firma AS DATE)) AS ANO_SUSCRIPCION,'NO DEFINIDO' AS CAUSAL_CONTRATACION_DIRECTA,0 AS VALOR_INICIAL_CONTRATO,'NO DEFINIDO' AS DEPARTAMENTO_EJECUCION_1,fecha_de_inicio_del_contrato AS FECHA_INICIO,fecha_de_fin_del_contrato AS FECHA_FIN,CASE WHEN proveedor_adjudicado LIKE '%CONSORCIO%' OR proveedor_adjudicado LIKE 'UT %' OR proveedor_adjudicado LIKE 'UNI%N TEMPORAL%' OR proveedor_adjudicado LIKE '% UT %' THEN 1 ELSE 0 END AS MARCA_CONSORCIO_UT,UPPER(destino_gasto) AS TIPO_GASTO,CASE 
        WHEN UPPER(modalidad_de_contratacion) LIKE '%CONCURSO%' THEN 'CONCURSO DE MERITOS'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%CONTRATACI%DIRECTA%' THEN 'CONTRATACION DIRECTA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%M_NIMA%CUANT%' THEN 'MINIMA CUANTIA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%LICITAC%' THEN 'LICITACION PUBLICA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%ESPECIAL%' THEN 'OTRAS FORMAS DE CONTRATACION DIRECTA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%SELECCI%ABREVIADA%' THEN 'SELECCION ABREVIADA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%CONVENIO%' THEN 'OTRAS FORMAS DE CONTRATACION DIRECTA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%ENAJENAC%' THEN 'ENAJENACION'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%NO%DEFINIDO%' THEN 'OTRO' 
        WHEN UPPER(modalidad_de_contratacion) LIKE '%INVITACI%' 
        OR UPPER(modalidad_de_contratacion) LIKE '%PRESENTAR%INTER%' THEN 'PRESENTACION OFERTAS'
        ELSE UPPER(modalidad_de_contratacion) END AS MODALIDAD,'NO DEFINIDO' AS MUNICIPIO_EJECUCION_1,'NO DEFINIDO' AS NIVEL_ENTIDAD,'NO DEFINIDO' AS NUMERO_CONSTANCIA,
        origen_de_los_recursos AS ORIGEN_RECURSOS,'NO DEFINIDO' AS PLAZO_EJEC_CONTRATO,'NO DEFINIDO' AS REGIMEN_DE_CONTRATACION,CASE WHEN urlproceso LIKE '%_url_%' THEN get_json_object(urlproceso,'$.url' ) ELSE urlproceso END AS ENLACE,B.sector AS SECTOR1,SC.SECTOR AS SECTOR2,
        TRIM(UPPER(SC.SUBSECTOR)) AS SUBSECTOR,TRIM(UPPER(SC.CONTRALORIA_DELEGADA)) AS CONTRALORIA_DELEGADA,0 AS VALOR_TOTAL_ADICIONES,'NO DEFINIDO' AS CORREGIDO,c_digo_bpin AS CODIGO_BPIN,espostconflicto AS ESPOSTCONFLICTO,estado_contrato AS ESTADO_CONTRATO,ultima_actualizacion AS FECHA_ACTUALIZACION,{fecha_actual} AS FECHA_CARGA,PB.ID_SEGMENTO,UPPER(PB.NOMBRE_SEGMENTO) AS NOMBRE_SEGMENTO,PB.ID_FAMILIA,UPPER(PB.NOMBRE_FAMILIA) AS NOMBRE_FAMILIA,PB.ID_CLASE,UPPER(PB.NOMBRE_CLASE)AS NOMBRE_CLASE,PB.ID_GRUPO,UPPER(PB.NOMBRE_GRUPO) AS NOMBRE_GRUPO,PB.ID_PRODUCTO,UPPER(PB.NOMBRE_PRODUCTO) AS NOMBRE_PRODUCTO,proceso_de_compra AS NUMERO_PROCESO,tipo_de_contrato AS TIPO_DE_CONTRATO,'NO DEFINIDO' AS COMPROMISO_PRESUPUESTAL,'NO DEFINIDO' AS DEPARTAMENTO_EJECUCION_2,'NO DEFINIDO' AS DEPARTAMENTO_EJECUCION_3,'NO DEFINIDO' AS MUNICIPIO_EJECUCION_2,'NO DEFINIDO' AS MUNICIPIO_EJECUCION_3,DATEDIFF(fecha_de_fin_del_contrato,COALESCE(CAST(fecha_de_inicio_de_ejecucion AS DATE),
        CAST(fecha_de_inicio_del_contrato AS DATE),CAST(fecha_de_firma AS DATE))) AS DURACION_CONTRATO,UPPER(tipo_de_identificaci_n_representante_legal) AS TIPO_ID_REP_LEGAL,identificaci_n_representante_legal AS IDENTIFICACION_REP_LEGAL,nombre_representante_legal AS NOMBRE_REP_LEGAL,orden AS ORDEN,valor_de_pago_adelantado AS VALOR_ANTICIPO,valor_facturado AS VALOR_FACTURADO,valor_pagado AS VALOR_PAGADO,'NO DEFINIDO' AS PROPONENTES_SELECCIONADOS,dias_adicionados AS TIEMPO_ADICIONES_DIAS,liquidaci_n AS LIQUIDACION,anno_bpin AS ANNO_BPIN,estado_bpin AS ESTADO_BPIN,valor_amortizado AS VALOR_AMORTIZADO,reversion AS REVERSION,es_grupo AS ES_GRUPO,fecha_de_fin_de_ejecucion AS FECHA_DE_FIN_DE_EJECUCION,fecha_de_inicio_de_ejecucion AS FECHA_DE_INICIO_DE_EJECUCION
    FROM mdlo_contractual.staging.secop2 A
    LEFT JOIN mdlo_contractual.cleansed.secop2 B ON I.id_contrato = B.id_contrato
    LEFT JOIN mdlo_contractual.insumos.bienes_servicios_secop PB ON PB.ID_PRODUCTO=RIGHT(codigo_de_categoria_principal,8)
    LEFT JOIN PRE_SUJETOS_CONTROL SC ON SC.NIT=NIT_ENTIDAD
    WHERE A.estado_contrato NOT IN ('En aprobación','Borrador','enviado Proveedor','Cancelado') AND row = 1 AND B.id_contrato IS NULL
    """
    df=spark.sql(query).persist(StorageLevel.MEMORY_AND_DISK)
    # display(df.limit(10))

# COMMAND ----------

# VARIABLES SIN USAR SECOP II
    # SELECT codigo_de_categoria_principal AS CODIGO_DE_CATEGORIA_PRINCIPAL,condiciones_de_entrega AS CONDICIONES_DE_ENTREGA,obligaci_n_ambiental AS OBLIGACIONES_AMBIENTALES,obligaciones_postconsumo AS OBLIGACIONES_POSTCONSUMO,urlproceso AS URLPROCESO,valor_pendiente_de AS VALOR_PENDIENTE_DE_AMORTIZACION,valor_pendiente_de_ejecucion AS VALOR_PENDIENTE_DE_EJECUCION,valor_pendiente_de_pago AS VALOR_PENDIENTE_DE_PAGO,localizaci_n AS MUNICIPIO,ciudad AS CIUDAD,rama AS RAMA,entidad_centralizada AS ENTIDAD_CENTRALIZADA,justificacion_modalidad_de AS JUSTIFICACION_MODALIDAD,es_pyme AS ES_PYME,saldo_cdp AS SALDO_CDP,saldo_vigencia AS SALDO_VIGENCIA,destino_gasto AS DESTINO_GASTO,puntos_del_acuerdo AS PUNTOS_DEL_ACUERDO,pilares_del_acuerdo AS PILARES_DEL_ACUERDO,nacionalidad_representante_legal AS NACIONALIDAD_REPRESENTANTE_LEGAL,g_nero_representante_legal AS GENERO_REPRESENTANTE_LEGAL,presupuesto_general_de_la_nacion_pgn AS VALOR_PGN,sistema_general_de_participaciones AS VALOR_SGP,sistema_general_de_regal_as AS VALOR_SGR,recursos_propios_alcald_as_gobernaciones_y_resguardos_ind_genas_ AS VALOR_RECURSOS_PROPIOS_AGYRI,recursos_de_credito AS VALOR_CREDITO,recursos_propios AS VALOR_RECURSOS_PROPIOS,codigo_entidad AS CODIGO_ENTIDAD,fecha_inicio_liquidacion AS FECHA_INICIO_LIQUIDACION,fecha_fin_liquidacion AS FECHA_FIN_LIQUIDACION,habilita_pago_adelantado AS HABILITA_PAGO_ADELANTADO,

# COMMAND ----------

# DBTITLE 1,Limpiando texto en ciertas columnas de texto
# df = spark.sql(f"SELECT * FROM mdlo_contractual.cleansed.secop2").persist(StorageLevel.MEMORY_AND_DISK)
# cleaning_udf=udf(cf.limpieza_texto_sencilla)
# df = df.withColumn("NOMBRE_ENTIDAD", cleaning_udf(col("NOMBRE_ENTIDAD")))
# df = df.withColumn("NOMBRE_CONTRATISTA", cleaning_udf(col("NOMBRE_CONTRATISTA")))
# df = df.withColumn("NOMBRE_REP_LEGAL", cleaning_udf(col("NOMBRE_REP_LEGAL")))
# df = df.withColumn("OBJETO_CONTRATO", cleaning_udf(col("OBJETO_CONTRATO")))
# df = df.withColumn("TIPO_DE_CONTRATO", cleaning_udf(col("TIPO_DE_CONTRATO")))
# df = df.withColumn("DEPARTAMENTO_SV", cleaning_udf(col("DEPARTAMENTO_SV")))
# df = df.withColumn("MUNICIPIO_SV", cleaning_udf(col("MUNICIPIO_SV")))
# df = df.withColumn("MODALIDAD", cleaning_udf(col("MODALIDAD")))
# df = df.withColumn("SECTOR", cleaning_udf(col("SECTOR")))
# df = df.withColumn("MUNICIPIO", cleaning_udf(col("MUNICIPIO")))
# df = df.withColumn("CIUDAD", cleaning_udf(col("CIUDAD")))

# COMMAND ----------

# DBTITLE 1,Limpiando identificación de entidad, contratista y representante legal
# cleaning_udf=udf(cf.limpieza_identificacion_sencilla)
# df = df.withColumn("NIT_ENTIDAD", cleaning_udf(col("NIT_ENTIDAD")))
# df = df.withColumn("IDENTIFICACION_CONTRATISTA", cleaning_udf(col("IDENTIFICACION_CONTRATISTA")))
# df = df.withColumn("IDENTIFICACION_REP_LEGAL", cleaning_udf(col("IDENTIFICACION_REP_LEGAL")))

# COMMAND ----------

# DBTITLE 1,Mapear tipos de manera correcta
mapping_expr = create_map([lit(x) for x in chain(*cf.replace_dict_departamento.items())])
# df = df.withColumn('DEPARTAMENTO_SV', mapping_expr[df['DEPARTAMENTO_SV']])
mapping_expr = create_map([lit(x) for x in chain(*cf.replace_dict_region.items())])
# df = df.withColumn('REGION_SV', mapping_expr[df['DEPARTAMENTO_SV']])
mapping_expr = create_map([lit(x) for x in chain(*cf.replace_tipo_persona.items())])
df = df.withColumn('TIPO_PERSONA_CONTRATISTA', mapping_expr[df['TIPO_ID_CONTRATISTA']])
mapping_expr = create_map([lit(x) for x in chain(*cf.replace_tipo_documento.items())])
df = df.withColumn('TIPO_ID_CONTRATISTA', mapping_expr[df['TIPO_ID_CONTRATISTA']])
df = df.withColumn('TIPO_ID_REP_LEGAL', mapping_expr[df['TIPO_ID_REP_LEGAL']])
# mapping_expr = create_map([lit(x) for x in chain(*cf.replace_tipo_proceso.items())])
# df = df.withColumn('MODALIDAD', mapping_expr[df['MODALIDAD']])

# COMMAND ----------

df = df.withColumn("TIEMPO_ADICIONES_DIAS", col("TIEMPO_ADICIONES_DIAS").cast(IntegerType()))
df = df.withColumn("PLAZO_EJEC_CONTRATO", col("PLAZO_EJEC_CONTRATO").cast(IntegerType()))
df = df.withColumn("VALOR_TOTAL_CONTRATO", col("VALOR_TOTAL_CONTRATO").cast(DoubleType()))
df = df.withColumn("VALOR_ANTICIPO", col("VALOR_ANTICIPO").cast(DoubleType()))
df = df.withColumn("VALOR_PAGADO", col("VALOR_PAGADO").cast(DoubleType()))
df = df.withColumn("VALOR_AMORTIZADO", col("VALOR_AMORTIZADO").cast(DoubleType()))
df = df.withColumn("VALOR_FACTURADO", col("VALOR_FACTURADO").cast(DoubleType()))
df = df.withColumn("FECHA_SUSCRIPCION", col("FECHA_SUSCRIPCION").cast(DateType()))
df = df.withColumn("FECHA_INICIO", col("FECHA_INICIO").cast(DateType()))
df = df.withColumn("FECHA_FIN", col("FECHA_FIN").cast(DateType()))
df = df.withColumn("FECHA_INICIO_EJECUCION", col("FECHA_INICIO_EJECUCION").cast(DateType()))
df = df.withColumn("FECHA_FIN_EJECUCION", col("FECHA_FIN_EJECUCION").cast(DateType()))
df = df.withColumn("FECHA_ACTUALIZACION", col("FECHA_ACTUALIZACION").cast(DateType()))
df = df.withColumn("FECHA_CARGA_UA", col("FECHA_CARGA_UA").cast(DateType()))
if tipo_cargue=='TOTAL':
    df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.cleansed.secop2')
else:
    df.write.mode("append").saveAsTable('mdlo_contractual.cleansed.secop2')
df.unpersist()
table_comment = "Información de contratación de SECOP II depurada"
query = f"COMMENT ON TABLE mdlo_contractual.cleansed.secop2 IS '{table_comment}'"
spark.sql(query)