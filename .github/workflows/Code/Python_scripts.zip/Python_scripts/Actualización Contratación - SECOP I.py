# Databricks notebook source
# MAGIC %md 
# MAGIC <h1> NO EDITAR, POR FAVOR CLONARLO Y TRABAJAR EN SU PROPIO WORKSPACE <h/1>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Libraries

# COMMAND ----------

# DBTITLE 1,Load libraries
import sys
import os
# Agrega la ruta de la carpeta Funciones al path del sistema
sys.path.insert(1, os.path.join(r'/Workspace/Shared/produccion/MDLO_CONTRACTUAL', "Modules"))
from datetime import date
# import koalas as ks
from pyspark.sql.types import *
from pyspark.sql.functions import approxCountDistinct,col,pandas_udf,udf,when,create_map,lit
from itertools import chain
from pyspark import StorageLevel
import cleaning_functions_DIARI as cf
import pandas as pd
fecha_actual=str(date.today())
anio_actual=date.today().year

# COMMAND ----------

# dbutils.widgets.dropdown("TIPO CARGUE", "DELTA", ["DELTA", "TOTAL"])
tipo_cargue = dbutils.widgets.get("TIPO CARGUE")
tipo_cargue

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cargue a staging (ORI en .168)

# COMMAND ----------

# DBTITLE 1,Primer cargue de SECOP I proveniente de Datos Abiertos

if tipo_cargue=='TOTAL':
  query=f"""CREATE OR REPLACE TABLE mdlo_contractual.staging.secop1 AS
  SELECT A.*
  FROM cd_gpif.`900514813`.S1_CONT_PROC A
  WHERE A.id_adjudicacion != 'Sin Adjudicar'"""
  spark.sql(query)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE mdlo_contractual.staging.origen_recursos_secop1 AS(
# MAGIC WITH  PRE as (select id_adjudicacion,CASE WHEN orig_rec_nombre = 'Asignación Especial del Sistema General de Participación para Resguardos Indígenas - AESGPRI' THEN 'SGP RESGUARDOS INDÍGENAS'
# MAGIC WHEN orig_rec_nombre = 'Presupuesto General de la Nación  PGN' THEN 'PGN'
# MAGIC WHEN orig_rec_nombre = 'Sistema General de Regalías - SGR' THEN 'SGR'
# MAGIC WHEN orig_rec_nombre ='Recursos propios'THEN 'RECURSOS PROPIOS'
# MAGIC WHEN orig_rec_nombre ='Recursos Propios (Alcaldías, Gobernaciones y Resguardos Indígenas)' THEN
# MAGIC 'RECURSOS PROPIOS (ALCALDIAS GOBERNACIONES Y RESGUARDOS INDIGENAS)'
# MAGIC WHEN orig_rec_nombre = 'Otros recursos' THEN 'OTROS'
# MAGIC WHEN orig_rec_nombre = 'Sistema General de Participaciones - SGP' THEN 'SGP' ELSE mdlo_contractual.reporting.limpieza_texto_sencilla(orig_rec_nombre) END AS ORIGEN_RECURSOS,valor AS VALOR_RECURSOS, CODIGO_BPIN AS BPIN
# MAGIC FROM cd_gpif.`900514813`.`s1_origen_recursos` WHERE valor!='0')
# MAGIC SELECT id_adjudicacion AS ID_ADJUDICACION, CONCAT_WS(' | ',COLLECT_SET(ORIGEN_RECURSOS)) AS ORIGEN_RECURSOS,CONCAT_WS(' | ',COLLECT_SET(VALOR_RECURSOS)) AS VALOR_DISTRIBUIDO_RECURSOS, CONCAT_WS(' | ',COLLECT_SET(BPIN)) AS CODIGO_BPIN FROM PRE GROUP BY id_adjudicacion)

# COMMAND ----------

# DBTITLE 1,Delta cargue en staging de datos abiertos
if tipo_cargue=='DELTA':
    query=f"""
    SELECT
    A.uid,
    A.anno_cargue_secop,
    A.anno_firma_contrato,
    A.nivel_entidad,
    A.orden_entidad,
    A.nombre_entidad,
    A.nit_de_la_entidad,
    A.c_digo_de_la_entidad,
    A.id_modalidad,
    A.modalidad_de_contratacion,
    A.estado_del_proceso,
    A.causal_de_otras_formas_de,
    A.id_regimen_de_contratacion,
    A.nombre_regimen_de_contratacion,
    A.id_objeto_a_contratar,
    A.objeto_a_contratar,
    A.detalle_del_objeto_a_contratar,
    A.tipo_de_contrato,
    A.municipio_de_obtencion,
    A.municipio_de_entrega,
    A.municipios_ejecucion,
    A.fecha_de_cargue_en_el_secop,
    A.numero_de_constancia,
    A.numero_de_proceso,
    A.numero_de_contrato,
    A.cuantia_proceso,
    A.id_grupo,
    A.nombre_grupo,
    A.id_familia,
    A.nombre_familia,
    A.id_clase,
    A.nombre_clase,
    A.id_adjudicacion,
    A.tipo_identifi_del_contratista,
    A.identificacion_del_contratista,
    A.nom_razon_social_contratista,
    A.dpto_y_muni_contratista,
    A.tipo_doc_representante_legal,
    A.identific_representante_legal,
    A.nombre_del_represen_legal,
    A.fecha_de_firma_del_contrato,
    A.fecha_ini_ejec_contrato,
    A.plazo_de_ejec_del_contrato,
    A.rango_de_ejec_del_contrato,
    A.tiempo_adiciones_en_dias,
    A.tiempo_adiciones_en_meses,
    A.fecha_fin_ejec_contrato,
    A.compromiso_presupuestal,
    A.cuantia_contrato,
    A.valor_total_de_adiciones,
    A.valor_contrato_con_adiciones,
    A.objeto_del_contrato_a_la,
    A.proponentes_seleccionados,
    A.calificacion_definitiva,
    A.id_sub_unidad_ejecutora,
    A.nombre_sub_unidad_ejecutora,
    A.ruta_proceso_en_secop_i,
    A.moneda,
    A.es_postconflicto,
    A.marcacion_adiciones,
    A.posicion_rubro,
    A.nombre_rubro,
    A.valor_rubro,
    A.sexo_replegal,
    A.pilar_acuerdo_paz,
    A.punto_acuerdo_paz,
    A.municipio_entidad,
    A.departamento_entidad,
    A.ultima_actualizacion,
    A.fecha_liquidacion,
    A.cumpledecreto248,
    A.incluyebienesdecreto248
    FROM cd_gpif.`900514813`.S1_CONT_PROC A
    LEFT JOIN mdlo_contractual.staging.secop1 B ON A.uid = B.uid 
    WHERE B.uid is null AND (a.anno_cargue_secop BETWEEN 2014 AND {anio_actual} or a.anno_firma_contrato in ('2014','2015')) AND A.id_adjudicacion != 'Sin Adjudicar'"""

    row_count = spark.sql(f"SELECT COUNT(1) FROM mdlo_contractual.staging.secop1").collect()[0][0]
    print("Original number of rows in the table staging SECOP I:", row_count)

    df=spark.sql(query)#.persist(StorageLevel.MEMORY_AND_DISK)
    print("Number of rows new to append to staging SECOP I:",df.count())

    # df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.staging.secop1')
    df.write.mode("append").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.staging.secop1')
    row_count = spark.sql(f"SELECT COUNT(1) FROM mdlo_contractual.staging.secop1").collect()[0][0]
    print("Current number of rows in the table staging SECOP I:", row_count)
    #df.unpersist()

# COMMAND ----------

# %sql
# ALTER TABLE mdlo_contractual.staging.secop1
# ALTER COLUMN anno_cargue_secop DATA_TYPE  TO INT;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cargue de staging a cleansed (STG in .168)
# MAGIC <ol>
# MAGIC <li> Tomar contratos del esquema staging que no están cleansed y cuyo id_adjudicacion no sea nulo
# MAGIC <li> Fundir con la tabla s1_origen_recursos para sacar información del origen de recursos
# MAGIC <li> La tabla de origen de recursos necesita reclasificación y seleccionar el primero por id_adjudicación de acuerdo al valor.
# MAGIC <li> Duración lo calcula usando DATEDIFF entre fecha inicio y fin de ejecución.
# MAGIC <li> Extraer URL del JSON usando get_json_object.
# MAGIC <li> Colocar en mayúsculas el valor de múltiples campos.
# MAGIC <li> Corrección municipio ejecución, entidad y nombre de entidad está jodido. Planear generalidad y corregirlo. <br>
# MAGIC Crea campo PERSONERIA, CONCEJO, ALCALDIA, GOBERNACIÓN <br>
# MAGIC Mejor tomar campo DEPARTAMENTO_ENTIDAD,MUNICIPIO_ENTIDAD y asociarlo a DIVIPOLA
# MAGIC <li> Derivar DEPARTAMENTO_EJECUCION y MUNICIPIO_EJECUCION para 3 diferentes opciones con un split(";")
# MAGIC <li> Limpieza IDENTIFICACIÓN CONTRATISTA
# MAGIC <li> Limpieza NOMBRE_CONTRATISTA/NOMBRE_ENTIDAD son caracteres especiales y tildes
# MAGIC <li> El objeto se toma el más largo entre detalle_del_objeto_a_contratar y objeto_del_contrato_a_la_firma. Limpiar caracteres especiales y tildes
# MAGIC <li> Extraer ID_SEGMENTO y NOMBRE_SEGMENTO a partir de cruce con la tabla BIENES Y SERVICIOS.
# MAGIC <li> Corrección de campos cuantia_contrato y valor_contrato_con_adiciones. Revisar los que tienen moneda = 'Dolares (USD)'
# MAGIC <li> Extraer plazo de ejecución en días usando rango_ejec_del_contrato y plazo_de_ejec_del_contrato.
# MAGIC <li> Columna MARCA_CONSORCIO_UT sale de mirar NOMBRE_CONTRATISTA.
# MAGIC </ol> 

# COMMAND ----------

# DBTITLE 1,Primer cargue de la limpieza de datos en staging
if tipo_cargue=='TOTAL':
        query=f"""CREATE OR REPLACE TABLE mdlo_contractual.cleansed.secop1 AS
        WITH PRE_BIENES AS (
        SELECT id_segmento,MAX(nombre_segmento) AS nombre_segmento
        FROM mdlo_contractual.insumos.bienes_servicios_secop
        GROUP BY id_segmento
        )

        SELECT 'SECOP I' AS FUENTE,
        I.uid as ID_CONTRATO,
        mdlo_contractual.reporting.limpieza_dv_sencilla(mdlo_contractual.reporting.limpieza_id_sencilla(I.nit_de_la_entidad)) as NIT_ENTIDAD,
        mdlo_contractual.reporting.limpieza_texto_sencilla(I.nombre_entidad) as NOMBRE_ENTIDAD,
        mdlo_contractual.reporting.limpieza_texto_sencilla(I.departamento_entidad) as DEPARTAMENTO_SV,
        mdlo_contractual.reporting.limpieza_texto_sencilla(I.municipio_entidad) as MUNICIPIO_SV,
        TRIM(UPPER(I.tipo_identifi_del_contratista)) as TIPO_ID_CONTRATISTA,
        mdlo_contractual.reporting.limpieza_dv_sencilla(mdlo_contractual.reporting.limpieza_id_sencilla(I.identificacion_del_contratista)) as IDENTIFICACION_CONTRATISTA,
        mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(I.nom_razon_social_contratista))as NOMBRE_CONTRATISTA,
        --TRIM(UPPER(I.nom_razon_social_contratista)) as NOMBRE_CONTRATISTA,
        I.fecha_de_firma_del_contrato as FECHA_SUSCRIPCION,
        I.numero_de_contrato as NUMERO_CONTRATO,
        I.valor_contrato_con_adiciones as VALOR_TOTAL_CONTRATO,
        CASE WHEN LENGTH(mdlo_contractual.reporting.limpieza_texto_sencilla(I.objeto_del_contrato_a_la))>
        LENGTH(mdlo_contractual.reporting.limpieza_texto_sencilla(I.detalle_del_objeto_a_contratar)) THEN mdlo_contractual.reporting.limpieza_texto_sencilla(I.objeto_del_contrato_a_la) ELSE mdlo_contractual.reporting.limpieza_texto_sencilla(I.detalle_del_objeto_a_contratar) END AS OBJETO_CONTRATO,
        YEAR(I.fecha_de_firma_del_contrato) AS ANO_SUSCRIPCION,
        TRIM(UPPER(I.causal_de_otras_formas_de)) as CAUSAL_CONTRATACION_DIRECTA,
        0 AS VALOR_INICIAL_CONTRATO,
        mdlo_contractual.reporting.limpieza_texto_sencilla(SPLIT(SPLIT(I.municipios_ejecucion,";")[0],',')[0]) AS MUNICIPIO_EJECUCION_1,mdlo_contractual.reporting.limpieza_texto_sencilla(SPLIT(SPLIT(I.municipios_ejecucion,";")[0],',')[1]) AS DEPARTAMENTO_EJECUCION_1,
        I.fecha_fin_ejec_contrato as FECHA_FIN,
        I.fecha_ini_ejec_contrato as FECHA_INICIO,
        mdlo_contractual.reporting.clasificacion_contratistas(mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(I.nombre_entidad))) AS CLASIFICACION_ENTIDAD_STD,
        mdlo_contractual.reporting.clasificacion_contratistas(mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(I.nom_razon_social_contratista))) AS CLASIFICACION_CONTRATISTA_STD,
        --CASE WHEN mdlo_contractual.reporting.limpieza_texto_sencilla(I.nom_razon_social_contratista) RLIKE r'CONSORCIO|--\\bU.?T.?\\b|UNI.?NTEMPORAL|\\bCS\\b' THEN 1 ELSE 0 END AS MARCA_CONSORCIO_UT,
        'NO DEFINIDO' AS TIPO_GASTO,
        CASE 
        WHEN UPPER(modalidad_de_contratacion) LIKE '%CONCURSO%' THEN 'CONCURSO DE MERITOS'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%CONTRATACI%DIRECTA%' THEN 'CONTRATACION DIRECTA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%M_NIMA%CUANT%' THEN 'MINIMA CUANTIA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%LICITAC%' THEN 'LICITACION PUBLICA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%ESPECIAL%' THEN 'OTRAS FORMAS DE CONTRATACION DIRECTA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%SELECCI%ABREVIADA%' THEN 'SELECCION ABREVIADA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%CONVENIO%' THEN 'OTRAS FORMAS DE CONTRATACION DIRECTA'
        WHEN UPPER(modalidad_de_contratacion) LIKE '%INVITACI%' 
        OR UPPER(modalidad_de_contratacion) LIKE '%PRESENTAR%INTER%' THEN 'PRESENTACION OFERTAS'
        ELSE UPPER(modalidad_de_contratacion) END AS MODALIDAD,
        TRIM(UPPER(I.nivel_entidad)) as NIVEL_ENTIDAD,
        I.numero_de_constancia as NUMERO_CONSTANCIA,
        OR.ORIGEN_RECURSOS,OR.VALOR_DISTRIBUIDO_RECURSOS,
        CASE WHEN I.rango_de_ejec_del_contrato= 'M' THEN 
        CAST(I.plazo_de_ejec_del_contrato AS INT)*30 ELSE CAST(I.plazo_de_ejec_del_contrato AS INT) END AS PLAZO_EJEC_CONTRATO,
        TRIM(UPPER(I.nombre_regimen_de_contratacion)) as REGIMEN_DE_CONTRATACION,
        get_json_object(I.ruta_proceso_en_secop_i,"$.url" ) as ENLACE,
        'NO DEFINIDO' AS TIPO_PERSONA_CONTRATISTA,
        I.valor_total_de_adiciones as VALOR_TOTAL_ADICIONES,
        OR.CODIGO_BPIN,
        I.es_postconflicto as ESPOSTCONFLICTO,
        TRIM(UPPER(I.estado_del_proceso)) as ESTADO_CONTRATO,
        I.ultima_actualizacion as FECHA_ACTUALIZACION,
        TRIM(UPPER(I.id_clase)) as ID_CLASE,
        TRIM(UPPER(I.nombre_clase)) as NOMBRE_CLASE,
        TRIM(UPPER(I.id_familia)) as ID_FAMILIA,
        TRIM(UPPER(I.nombre_familia)) as NOMBRE_FAMILIA,
        TRIM(UPPER(I.id_grupo)) as ID_GRUPO,
        TRIM(UPPER(REGEXP_REPLACE(I.nombre_grupo,r'(\[[A-Z]\] )',''))) as NOMBRE_GRUPO,
        CAST(I.id_clase*100 AS BIGINT) AS ID_PRODUCTO,'NO DEFINIDO' AS NOMBRE_PRODUCTO,
        PB.ID_SEGMENTO,UPPER(TRIM(PB.NOMBRE_SEGMENTO)) AS NOMBRE_SEGMENTO,
        I.numero_de_proceso as NUMERO_PROCESO,
        TRIM(UPPER(I.tipo_de_contrato)) as TIPO_DE_CONTRATO,
        TRIM(UPPER(I.compromiso_presupuestal)) as COMPROMISO_PRESUPUESTAL,
        mdlo_contractual.reporting.limpieza_texto_sencilla(SPLIT(SPLIT(I.municipios_ejecucion,";")[1],',')[0]) AS MUNICIPIO_EJECUCION_2,mdlo_contractual.reporting.limpieza_texto_sencilla(SPLIT(SPLIT(I.municipios_ejecucion,";")[1],',')[1]) AS DEPARTAMENTO_EJECUCION_2,
        mdlo_contractual.reporting.limpieza_texto_sencilla(SPLIT(SPLIT(I.municipios_ejecucion,";")[2],',')[0]) AS MUNICIPIO_EJECUCION_3,mdlo_contractual.reporting.limpieza_texto_sencilla(SPLIT(SPLIT(I.municipios_ejecucion,";")[2],',')[1]) AS DEPARTAMENTO_EJECUCION_3,
        DATEDIFF(I.fecha_fin_ejec_contrato,I.fecha_ini_ejec_contrato) AS DURACION_CONTRATO,
        TRIM(UPPER(I.tipo_doc_representante_legal)) as TIPO_ID_REP_LEGAL,
        TRIM(REGEXP_REPLACE(I.identific_representante_legal,r'[^0-9]' ,'')) as IDENTIFICACION_REP_LEGAL,
        TRIM(UPPER(I.nombre_del_represen_legal)) as NOMBRE_REP_LEGAL,
        TRIM(UPPER(I.orden_entidad)) as ORDEN_ENTIDAD,
        TRIM(UPPER(I.proponentes_seleccionados)) as PROPONENTES_SELECCIONADOS,
        I.tiempo_adiciones_en_dias as TIEMPO_ADICIONES_DIAS,
        'NO DEFINIDO' AS LIQUIDACION,'NO DEFINIDO' AS ANNO_BPIN,
        'NO DEFINIDO' AS ESTADO_BPIN, 'NO DEFINIDO' AS VALOR_AMORTIZADO, 'NO DEFINIDO' AS VALOR_ANTICIPO,
        'NO DEFINIDO' AS VALOR_FACTURADO, 'NO DEFINIDO' AS VALOR_PAGADO,'NO DEFINIDO' AS REVERSION, 'NO DEFINIDO' AS ES_GRUPO,
        'NO DEFINIDO' AS FECHA_FIN_EJECUCION,'NO DEFINIDO' AS FECHA_INICIO_EJECUCION,
        '{fecha_actual}' AS FECHA_CARGA_UA
        FROM mdlo_contractual.staging.secop1 I
        LEFT JOIN mdlo_contractual.staging.origen_recursos_secop1 OR ON OR.id_adjudicacion = I.id_adjudicacion
        LEFT JOIN PRE_BIENES PB ON PB.id_segmento=LEFT(I.id_familia,2)
        WHERE I.id_adjudicacion != 'Sin Adjudicar'
        """
        spark.sql(query)
        df = spark.sql(f"SELECT * FROM mdlo_contractual.cleansed.secop1").persist(StorageLevel.MEMORY_AND_DISK)

# COMMAND ----------

if tipo_cargue=='DELTA':
    query=f"""
    WITH PRE_ORIGEN AS (
    SELECT id_adjudicacion, id_origen_de_los_recursos,orig_rec_nombre AS origen_de_los_recursos,codigo_bpin,valor,
    ROW_NUMBER()OVER(PARTITION BY id_adjudicacion ORDER BY valor DESC) row
    FROM cd_gpif.`900514813`.`s1_origen_recursos`),
    PRE_BIENES AS (
    SELECT id_segmento,MAX(nombre_segmento) AS nombre_segmento
    FROM mdlo_contractual.insumos.bienes_servicios_secop
    GROUP BY id_segmento
    )
    SELECT 'SECOP I' AS FUENTE, 
    I.uid as ID_CONTRATO,
    I.nit_de_la_entidad as NIT_ENTIDAD,
    TRIM(UPPER(I.nombre_entidad)) as NOMBRE_ENTIDAD,
    TRIM(UPPER(I.departamento_entidad)) as DEPARTAMENTO_SV,
    TRIM(UPPER(I.municipio_entidad)) as MUNICIPIO_SV,
    TRIM(UPPER(I.tipo_identifi_del_contratista)) as TIPO_ID_CONTRATISTA,
    I.identificacion_del_contratista as IDENTIFICACION_CONTRATISTA,
    TRIM(UPPER(I.nom_razon_social_contratista)) as NOMBRE_CONTRATISTA,
    I.fecha_de_firma_del_contrato as FECHA_SUSCRIPCION,
    I.numero_de_contrato as NUMERO_DEL_CONTRATO,
    I.valor_contrato_con_adiciones as VALOR_TOTAL_CONTRATO,
    TRIM(UPPER(I.objeto_a_contratar)) as OBJETO_A_CONTRATAR,
    CASE WHEN LENGTH(TRIM(UPPER(I.objeto_del_contrato_a_la)))>
    LENGTH(TRIM(UPPER(I.detalle_del_objeto_a_contratar))) THEN  TRIM(UPPER(I.objeto_del_contrato_a_la)) ELSE TRIM(UPPER(I.detalle_del_objeto_a_contratar)) END AS OBJETO_CONTRATO,
    YEAR(I.fecha_de_firma_del_contrato) AS ANO_SUSCRIPCION
    TRIM(UPPER(I.causal_de_otras_formas_de)) as CAUSAL_CONTRATACION_DIRECTA,
    0 AS VALOR_INICIAL_CONTRATO,
    UPPER(SPLIT(SPLIT(I.municipios_ejecucion,";")[0],',')[0]) AS MUNICIPIO_EJECUCION_1,UPPER(SPLIT(SPLIT(I.municipios_ejecucion,";")[0],',')[1]) AS DEPARTAMENTO_EJECUCION_1,
    I.fecha_fin_ejec_contrato as FECHA_FIN,
    I.fecha_ini_ejec_contrato as FECHA_INICIO,
    CASE WHEN I.nom_razon_social_contratista LIKE '%CONSORCIO%' OR I.nom_razon_social_contratista LIKE 'UT %' OR I.nom_razon_social_contratista LIKE 'UNI%N TEMPORAL%' OR I.nom_razon_social_contratista LIKE '% UT %' THEN 1 ELSE 0 END AS MARCA_CONSORCIO_UT,'NO DEFINIDO' AS TIPO_GASTO,
    CASE 
    WHEN UPPER(modalidad_de_contratacion) LIKE '%CONCURSO%' THEN 'CONCURSO DE MERITOS'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%CONTRATACI%DIRECTA%' THEN 'CONTRATACION DIRECTA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%M_NIMA%CUANT%' THEN 'MINIMA CUANTIA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%LICITAC%' THEN 'LICITACION PUBLICA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%ESPECIAL%' THEN 'OTRAS FORMAS DE CONTRATACION DIRECTA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%SELECCI%ABREVIADA%' THEN 'SELECCION ABREVIADA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%CONVENIO%' THEN 'OTRAS FORMAS DE CONTRATACION DIRECTA'
    WHEN UPPER(modalidad_de_contratacion) LIKE '%INVITACI%' 
    OR UPPER(modalidad_de_contratacion) LIKE '%PRESENTAR%INTER%' THEN 'PRESENTACION OFERTAS'
    ELSE UPPER(modalidad_de_contratacion) END AS MODALIDAD,
    UPPER(SPLIT(SPLIT(I.municipios_ejecucion,";")[0],',')[0]) AS MUNICIPIO_EJECUCION_2,UPPER(SPLIT(SPLIT(I.municipios_ejecucion,";")[1],',')[1]) AS DEPARTAMENTO_EJECUCION_2,
    TRIM(UPPER(I.nivel_entidad)) as NIVEL_ENTIDAD,
    I.numero_de_constancia as NUMERO_DE_CONSTANCIA,
    CASE WHEN PO.origen_de_los_recursos = 'Asignación Especial del Sistema General de Participación para Resguardos Indígenas - AESGPRI' THEN 'SGP RESGUARDOS INDÍGENAS'
    WHEN PO.origen_de_los_recursos = 'Presupuesto General de la Nación  PGN' THEN 'PGN'
    WHEN PO.origen_de_los_recursos = 'Sistema General de Regalías - SGR' THEN 'SGR'
    WHEN PO.origen_de_los_recursos IN ('Recursos Propios (Alcaldías, Gobernaciones y Resguardos Indígenas)','Recursos propios')THEN 'RECURSOS PROPIOS'
    WHEN PO.origen_de_los_recursos = 'Otros recursos' THEN 'OTROS'
    WHEN PO.origen_de_los_recursos = 'Sistema General de Participaciones - SGP' THEN 'SGP'
    ELSE TRIM(UPPER(PO.origen_de_los_recursos)) END AS ORIGEN_DE_LOS_RECURSOS,
    CASE WHEN I.rango_de_ejec_del_contrato= 'M' THEN 
    CAST(I.plazo_de_ejec_del_contrato AS INT)*30 ELSE CAST(I.plazo_de_ejec_del_contrato AS INT) END AS PLAZO_EJEC_CONTRATO,
    TRIM(UPPER(I.nombre_regimen_de_contratacion)) as REGIMEN_DE_CONTRATACION,
    get_json_object(I.ruta_proceso_en_secop_i,"$.url" ) as ENLACE,
    SC.SECTOR,SC.SUBSECTOR,SC.CONTRALORIA_DELEGADA,'NO DEFINIDO' AS TIPO_PERSONA_CONTRATISTA,
    I.valor_total_de_adiciones as VALOR_TOTAL_ADICIONES,
    PO.CODIGO_BPIN,
    I.es_postconflicto as ESPOSTCONFLICTO,
    TRIM(UPPER(I.estado_del_proceso)) as ESTADO_CONTRATO,
    I.ultima_actualizacion as FECHA_ACTUALIZACION,
    I.fecha_de_cargue_en_el_secop as FECHA_CARGA,
    I.id_clase as ID_CLASE,
    TRIM(UPPER(I.nombre_clase)) as NOMBRE_CLASE,
    I.id_familia as ID_FAMILIA,
    TRIM(UPPER(I.nombre_familia)) as NOMBRE_FAMILIA,
    I.id_grupo as ID_GRUPO,
    TRIM(UPPER(I.nombre_grupo)) as NOMBRE_GRUPO,
    PB.ID_PRODUCTO,PB.NOMBRE_PRODUCTO,
    PB.ID_SEGMENTO,PB.NOMBRE_SEGMENTO,
    I.numero_de_proceso as NUMERO_DE_PROCESO,
    TRIM(UPPER(I.tipo_de_contrato)) as TIPO_DE_CONTRATO,
    I.compromiso_presupuestal as COMPROMISO_PRESUPUESTAL,
    UPPER(SPLIT(SPLIT(I.municipios_ejecucion,";")[1],',')[0]) AS MUNICIPIO_EJECUCION_2,UPPER(SPLIT(SPLIT(I.municipios_ejecucion,";")[1],',')[1]) AS DEPARTAMENTO_EJECUCION_2,
    UPPER(SPLIT(SPLIT(I.municipios_ejecucion,";")[2],',')[0]) AS MUNICIPIO_EJECUCION_3,UPPER(SPLIT(SPLIT(I.municipios_ejecucion,";")[2],',')[1]) AS DEPARTAMENTO_EJECUCION_3,
    DATEDIFF(I.fecha_fin_ejec_contrato,I.fecha_ini_ejec_contrato) AS DURACION_CONTRATO,
    TRIM(UPPER(I.tipo_doc_representante_legal)) as TIPO_ID_REP_LEGAL,
    I.identific_representante_legal as IDENTIFICACION_REP_LEGAL,
    TRIM(UPPER(I.nombre_del_represen_legal)) as NOMBRE_REP_LEGAL,
    TRIM(UPPER(I.orden_entidad)) as ORDEN_ENTIDAD,
    I.proponentes_seleccionados as PROPONENTES_SELECCIONADOS,
    I.tiempo_adiciones_en_dias as TIEMPO_ADICIONES_EN_DIAS,
    'NO DEFINIDO' AS REGION_SV,'NO DEFINIDO' AS ANTICIPO,'NO DEFINIDO' AS LIQUIDACION,'NO DEFINIDO' AS ANNO_BPIN,
    'NO DEFINIDO' AS ESTADO_BPIN, 'NO DEFINIDO' AS VALOR_AMORTIZADO, 'NO DEFINIDO' AS VALOR_ANTICIPO,
    'NO DEFINIDO' AS VALOR_FACTURADO, 'NO DEFINIDO' AS VALOR_PAGADO,'NO DEFINIDO' AS REVERSION, 'NO DEFINIDO' AS ES_GRUPO,
    'NO DEFINIDO' AS FECHA_DE_FIN_DE_EJECUCION,'NO DEFINIDO' AS FECHA_DE_INICIO_DE_EJECUCION
    FROM mdlo_contractual.staging.secop1 I
    LEFT JOIN mdlo_contractual.cleansed.secop1 B ON I.uid = B.UID
    LEFT JOIN PRE_ORIGEN PO ON PO.id_adjudicacion = I.id_adjudicacion
    LEFT JOIN PRE_BIENES PB ON PB.id_segmento=LEFT(I.id_familia,2)
    WHERE B.UID IS NULL and I.id_adjudicacion != 'Sin Adjudicar' AND (PO.row = 1 OR PO.row IS NULL) AND SC.row=1
    """
    row_count = spark.sql(f"SELECT COUNT(1) FROM mdlo_contractual.cleansed.secop1").collect()[0][0]
    print("Original number of rows in the table cleansed SECOP I:", row_count)

    df=spark.sql(query).persist(StorageLevel.MEMORY_AND_DISK)
    print("Number of rows new to append to cleansed SECOP I:",df.count())

    # df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.cleansed.secop1')
    df.write.mode("append").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.cleansed.secop1')
    row_count = spark.sql(f"SELECT COUNT(1) FROM mdlo_contractual.cleansed.secop1").collect()[0][0]
    print("Current number of rows in the table cleansed SECOP I:", row_count)

# COMMAND ----------

# DBTITLE 1,Campos no usados
# #NO USADOS EN SECOP I
#  I.c_digo_de_la_entidad as C_DIGO_DE_LA_ENTIDAD,
#     I.anno_cargue_secop as ANNO_CARGUE_SECOP,
#     I.anno_firma_contrato as ANNO_FIRMA_DEL_CONTRATO,

#     I.id_modalidad as ID_TIPO_DE_PROCESO,
#     I.id_regimen_de_contratacion as ID_REGIMEN_DE_CONTRATACION,
#     I.id_objeto_a_contratar as ID_OBJETO_A_CONTRATAR,
#     I.municipio_de_obtencion as MUNICIPIO_OBTENCION,
#     I.municipio_de_entrega as MUNICIPIO_ENTREGA,
#     I.municipios_ejecucion as MUNICIPIOS_EJECUCION,
    
#     I.cuantia_proceso as CUANTIA_PROCESO,
#     I.id_adjudicacion as ID_ADJUDICACION,

#     TRIM(UPPER(I.dpto_y_muni_contratista)) as DPTO_Y_MUNI_CONTRATISTA,
#     I.tiempo_adiciones_en_meses as TIEMPO_ADICIONES_EN_MESES,
#     I.cuantia_contrato as CUANTIA_CONTRATO,
#     I.valor_total_de_adiciones as VALOR_TOTAL_DE_ADICIONES,
#     TRIM(UPPER(I.objeto_del_contrato_a_la)) as OBJETO_DEL_CONTRATO_A_LA_FIRMA,
#     I.calificacion_definitiva as CALIFICACION_DEFINITIVA,
#     I.id_sub_unidad_ejecutora as ID_SUB_UNIDAD_EJECUTORA,
#     TRIM(UPPER(I.nombre_sub_unidad_ejecutora)) as NOMBRE_SUB_UNIDAD_EJECUTORA,
#     I.moneda as MONEDA,
#     I.marcacion_adiciones as MARCACION_ADICIONES,
#     I.posicion_rubro as POSICION_RUBRO,
#     I.nombre_rubro as NOMBRE_RUBRO,
#     I.valor_rubro as VALOR_RUBRO,
#     I.pilar_acuerdo_paz as PILAR_ACUERDO_PAZ,
#     I.punto_acuerdo_paz as PUNTO_ACUERDO_PAZ, 
#     I.fecha_liquidacion as FECHA_LIQUIDACION,
    
#     --PO.id_origen_de_los_recursos,
#     --PO.valor,

# COMMAND ----------

# DBTITLE 1,Limpiando texto en ciertas columnas de texto
# df = spark.sql(f"SELECT * FROM mdlo_contractual.cleansed.secop1").persist(StorageLevel.MEMORY_AND_DISK)
# cleaning_udf=udf(cf.limpieza_texto_sencilla)
# df = df.withColumn("NOMBRE_ENTIDAD", cleaning_udf(col("NOMBRE_ENTIDAD")))
# df = df.withColumn("NOMBRE_CONTRATISTA", cleaning_udf(col("NOMBRE_CONTRATISTA")))
# df = df.withColumn("NOMBRE_REP_LEGAL", cleaning_udf(col("NOMBRE_REP_LEGAL")))
# df = df.withColumn("OBJETO_CONTRATO", cleaning_udf(col("OBJETO_CONTRATO")))
# df = df.withColumn("DEPARTAMENTO_SV", cleaning_udf(col("DEPARTAMENTO_SV")))
# df = df.withColumn("DEPARTAMENTO_EJECUCION_1", cleaning_udf(col("DEPARTAMENTO_EJECUCION_1")))
# df = df.withColumn("DEPARTAMENTO_EJECUCION_2", cleaning_udf(col("DEPARTAMENTO_EJECUCION_2")))
# df = df.withColumn("DEPARTAMENTO_EJECUCION_3", cleaning_udf(col("DEPARTAMENTO_EJECUCION_3")))
# df = df.withColumn("MUNICIPIO_SV", cleaning_udf(col("MUNICIPIO_SV")))
# df = df.withColumn("MUNICIPIO_EJECUCION_1", cleaning_udf(col("MUNICIPIO_EJECUCION_1")))
# df = df.withColumn("MUNICIPIO_EJECUCION_2", cleaning_udf(col("MUNICIPIO_EJECUCION_2")))
# df = df.withColumn("MUNICIPIO_EJECUCION_3", cleaning_udf(col("MUNICIPIO_EJECUCION_3")))
# df = df.withColumn("MODALIDAD", cleaning_udf(col("MODALIDAD")))

# COMMAND ----------

# DBTITLE 1,Limpiando identificación de entidad, contratista y representante legal
# cleaning_udf=udf(cf.limpieza_identificacion_sencilla)
# df = df.withColumn("NIT_ENTIDAD", cleaning_udf(col("NIT_ENTIDAD")))
# df = df.withColumn("IDENTIFICACION_CONTRATISTA", cleaning_udf(col("IDENTIFICACION_CONTRATISTA")))
# df = df.withColumn("IDENTIFICACION_REP_LEGAL", cleaning_udf(col("IDENTIFICACION_REP_LEGAL")))

# COMMAND ----------

# DBTITLE 1,Mapear tipos de manera correcta
# df = spark.sql(f"SELECT * FROM mdlo_contractual.cleansed.secop1 LIMIT 1000000").persist(StorageLevel.MEMORY_AND_DISK)
mapping_expr = create_map([lit(x) for x in chain(*cf.replace_dict_departamento.items())])
# df = df.withColumn('DEPARTAMENTO_SV', mapping_expr[df['DEPARTAMENTO_SV']])
df = df.withColumn('DEPARTAMENTO_EJECUCION_1', mapping_expr[df['DEPARTAMENTO_EJECUCION_1']])
df = df.withColumn('DEPARTAMENTO_EJECUCION_2', mapping_expr[df['DEPARTAMENTO_EJECUCION_2']])
df = df.withColumn('DEPARTAMENTO_EJECUCION_3', mapping_expr[df['DEPARTAMENTO_EJECUCION_3']])
mapping_expr = create_map([lit(x) for x in chain(*cf.replace_dict_region.items())])
# df = df.withColumn('REGION_SV', mapping_expr[df['DEPARTAMENTO_SV']])
mapping_expr = create_map([lit(x) for x in chain(*cf.replace_tipo_persona.items())])
df = df.withColumn('TIPO_PERSONA_CONTRATISTA', mapping_expr[df['TIPO_ID_CONTRATISTA']])
mapping_expr = create_map([lit(x) for x in chain(*cf.replace_tipo_documento.items())])
df = df.withColumn('TIPO_ID_CONTRATISTA', mapping_expr[df['TIPO_ID_CONTRATISTA']])
df = df.withColumn('TIPO_ID_REP_LEGAL', mapping_expr[df['TIPO_ID_REP_LEGAL']])
# mapping_expr = create_map([lit(x) for x in chain(*cf.replace_tipo_proceso.items())])
# df = df.withColumn('MODALIDAD_NEW', mapping_expr[df['MODALIDAD']])

# COMMAND ----------

df = df.withColumn("TIEMPO_ADICIONES_DIAS", col("TIEMPO_ADICIONES_DIAS").cast(IntegerType()))
df = df.withColumn("PLAZO_EJEC_CONTRATO", col("PLAZO_EJEC_CONTRATO").cast(IntegerType()))
df = df.withColumn("VALOR_TOTAL_CONTRATO", col("VALOR_TOTAL_CONTRATO").cast(DoubleType()))
df = df.withColumn("VALOR_ANTICIPO", col("VALOR_ANTICIPO").cast(DoubleType()))
df = df.withColumn("VALOR_PAGADO", col("VALOR_PAGADO").cast(DoubleType()))
df = df.withColumn("VALOR_AMORTIZADO", col("VALOR_AMORTIZADO").cast(DoubleType()))
df = df.withColumn("VALOR_FACTURADO", col("VALOR_FACTURADO").cast(DoubleType()))
df = df.withColumn("FECHA_SUSCRIPCION", col("FECHA_SUSCRIPCION").cast(DateType()))
df = df.withColumn("FECHA_INICIO", col("FECHA_INICIO").cast(DateType()))
df = df.withColumn("FECHA_FIN", col("FECHA_FIN").cast(DateType()))
df = df.withColumn("FECHA_INICIO_EJECUCION", col("FECHA_INICIO_EJECUCION").cast(DateType()))
df = df.withColumn("FECHA_FIN_EJECUCION", col("FECHA_FIN_EJECUCION").cast(DateType()))
df = df.withColumn("FECHA_ACTUALIZACION", col("FECHA_ACTUALIZACION").cast(DateType()))
df = df.withColumn("FECHA_CARGA_UA", col("FECHA_CARGA_UA").cast(DateType()))
if tipo_cargue=='TOTAL':
    df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.cleansed.secop1')
else:
    df.write.mode("append").saveAsTable('mdlo_contractual.cleansed.secop1')
df.unpersist()
table_comment = "Información de SECOP I limpia"
query = f"COMMENT ON TABLE mdlo_contractual.cleansed.secop1 IS '{table_comment}'"
spark.sql(query)