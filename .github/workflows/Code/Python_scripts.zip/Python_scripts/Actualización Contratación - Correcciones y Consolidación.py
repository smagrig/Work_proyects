# Databricks notebook source
# MAGIC %md 
# MAGIC <h1> NO EDITAR, POR FAVOR CLONARLO Y TRABAJAR EN SU PROPIO WORKSPACE <h/1>

# COMMAND ----------

from rapidfuzz import process
from rapidfuzz import fuzz
from pyspark import StorageLevel
import pandas as pd
from pyspark.sql.types import *
from pyspark.sql.functions import approxCountDistinct,col,pandas_udf,udf,when,create_map,lit,broadcast,levenshtein,max,struct,first

# COMMAND ----------

dbutils.widgets.dropdown("TIPO CARGUE", "DELTA", ["DELTA", "TOTAL"])
# dbutils.widgets.remove("TIPO CARGUE")
tipo_cargue = dbutils.widgets.get("TIPO CARGUE")
tipo_cargue

# COMMAND ----------

# DBTITLE 1,Estandarizar nombres de departamento y municipio
divipola = spark.sql(f"SELECT DISTINCT NOMBRE_DEPARTAMENTO AS DEPARTAMENTO_STD,NOMBRE_MUNICIPIO AS MUNICIPIO_STD FROM mdlo_contractual.insumos.divipola").toPandas()
def encontrar_municipio_coincidente(palabra,nombre_departamento):
    if tipo=='DEPARTAMENTO':
        lista_opciones=[name.replace('DEPARTAMENTO DE ','').replace('DEPARTAMENTO DEL ','') for name in divipola['DEPARTAMENTO_STD'].unique()]
    else:
        lista_opciones=divipola[divipola.DEPARTAMENTO_STD==nombre_departamento]['MUNICIPIO_STD'].unique()
    if (palabra is None) or (palabra.upper()=='NAN') or (palabra.upper()=='NO ENCONTRADO EN DATOS ABIERTOS'):
        return 'NO DEFINIDO'
    try:
        municipio_new, similarity_score, index = process.extractOne(f'{palabra}',lista_opciones,scorer=fuzz.token_sort_ratio)
        # if similarity_score>=60:
        return municipio_new
    except:
        return 'NO DEFINIDO'

# COMMAND ----------

df_municipios=spark.sql("""
SELECT DISTINCT DEPARTAMENTO_SV,MUNICIPIO_SV FROM mdlo_contractual.cleansed.secop1 
UNION SELECT DISTINCT DEPARTAMENTO_SV,MUNICIPIO_SV FROM mdlo_contractual.cleansed.secop2 
UNION SELECT DISTINCT DEPARTAMENTO_SV,MUNICIPIO_SV FROM mdlo_contractual.cleansed.sia 
UNION SELECT DISTINCT DEPARTAMENTO_SV,MUNICIPIO_SV FROM mdlo_contractual.reporting.contratacion_sia 
UNION SELECT DISTINCT DEPARTAMENTO_SV,'NO DEFINIDO' FROM mdlo_contractual.cleansed.sireci 
UNION SELECT DISTINCT DEPARTAMENTO_SV,'NO DEFINIDO' FROM mdlo_contractual.reporting.contratacion_sireci
""").persist(StorageLevel.MEMORY_AND_DISK)
# df_municipios=df.select(['DEPARTAMENTO_SV','MUNICIPIO_SV']).distinct().persist(StorageLevel.MEMORY_AND_DISK)
tipo='DEPARTAMENTO'
@pandas_udf("string")
def encontrar_municipio_coincidente_udf(col_palabra,col_departamento):
    return pd.Series([encontrar_municipio_coincidente(palabra,departamento) for palabra,departamento in zip(col_palabra,col_departamento)])
df_municipios =df_municipios.withColumn("DEPARTAMENTO_STD", encontrar_municipio_coincidente_udf(col("DEPARTAMENTO_SV"),col("DEPARTAMENTO_SV"))).persist(StorageLevel.MEMORY_AND_DISK)
tipo='MUNICIPIO'
@pandas_udf("string")
def encontrar_municipio_coincidente_udf(col_palabra,col_departamento):
    return pd.Series([encontrar_municipio_coincidente(palabra,departamento) for palabra,departamento in zip(col_palabra,col_departamento)])
df_municipios =df_municipios.withColumn("MUNICIPIO_STD", encontrar_municipio_coincidente_udf(col("MUNICIPIO_SV"),col("DEPARTAMENTO_STD"))).persist(StorageLevel.MEMORY_AND_DISK)
# display(df_municipios.join(divipola,on=['DEPARTAMENTO_STD','MUNICIPIO_STD'],how='left').limit(5))
df_municipios.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.insumos.correcciones_municipios_departamentos_sv')

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE mdlo_contractual.insumos.correcciones_municipios_departamentos_sv
# MAGIC SET MUNICIPIO_STD = 'SAN ANDRES DE TUMACO'
# MAGIC WHERE DEPARTAMENTO_STD='NARIÑO' AND MUNICIPIO_SV RLIKE r'TUMACO'

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE mdlo_contractual.insumos.correcciones_municipios_departamentos_sv
# MAGIC SET MUNICIPIO_STD = 'CARTAGENA DE INDIAS'
# MAGIC WHERE DEPARTAMENTO_STD='BOLIVAR' AND MUNICIPIO_SV RLIKE r'CARTAGENA'

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE mdlo_contractual.insumos.correcciones_municipios_departamentos_sv
# MAGIC SET MUNICIPIO_STD = 'NO DEFINIDO' WHERE MUNICIPIO_SV RLIKE r'NO DEFINIDO'

# COMMAND ----------

# DBTITLE 1,Corregir NIT Entidad vacío
df_base=spark.sql(f"SELECT DISTINCT NOMBRE_ENTIDAD FROM mdlo_contractual.cleansed.secop1 WHERE NIT_ENTIDAD = 'NO DEFINIDO'")
df_opciones = spark.sql("SELECT DISTINCT NIT,SUJETO_DE_CONTROL FROM mdlo_contractual.insumos.sujetos_control_unificada WHERE NIT NOT LIKE '%NIT%' --UNION SELECT DISTINCT NIT_ENTIDAD,NOMBRE_ENTIDAD FROM mdlo_contractual.reporting.contratacion_secop WHERE NIT_ENTIDAD != 'NO DEFINIDO'")
df_opciones_pandas=df_opciones.toPandas()
def encontrar_nit_entidad(palabra):
    lista_opciones=df_opciones_pandas.SUJETO_DE_CONTROL.unique()
    try:
        nombre_depurado, similarity_score, index = process.extractOne(f'{palabra}',lista_opciones,scorer=fuzz.token_set_ratio,score_cutoff=90)
        if nombre_depurado is not None:
            return nombre_depurado
        else:
            return 'SIN COINCIDENCIA'
    except:
        return 'NO DEFINIDO'
@pandas_udf("string")
def encontrar_nit_entidad_udf(col_palabra):
    return pd.Series([encontrar_nit_entidad(palabra) for palabra in col_palabra])
df_base =df_base.withColumn('NOMBRE_DEPURADO', encontrar_nit_entidad_udf(col('NOMBRE_ENTIDAD'))).persist(StorageLevel.MEMORY_AND_DISK)
df_base=df_base.where('NOMBRE_DEPURADO != "SIN COINCIDENCIA"')
df_depurado=df_base.join(df_opciones,df_base['NOMBRE_DEPURADO']==df_opciones['SUJETO_DE_CONTROL'],'inner').drop('SUJETO_DE_CONTROL')
df_depurado.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.insumos.correcciones_nit_entidad')

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO mdlo_contractual.cleansed.secop1 AS target
# MAGIC USING mdlo_contractual.insumos.correcciones_nit_entidad AS source
# MAGIC ON target.NOMBRE_ENTIDAD = source.NOMBRE_ENTIDAD AND target.NIT_ENTIDAD = 'NO DEFINIDO'
# MAGIC WHEN MATCHED THEN UPDATE SET target.NIT_ENTIDAD = source.NIT

# COMMAND ----------

# DBTITLE 1,Cargue de contratación total SECOP I y II
df1=spark.sql(f"""SELECT C.*,SC.CONTRALORIA_DELEGADA,SC.SECTOR,SC.SUBSECTOR,
CASE WHEN C.DEPARTAMENTO_SV='COLOMBIA' THEN C.DEPARTAMENTO_SV ELSE D.DEPTO_AJUST END AS DEPTO_AJUST,
CASE WHEN C.DEPARTAMENTO_SV='COLOMBIA' THEN C.MUNICIPIO_SV ELSE D.MUNI_AJUST END AS MUNI_AJUST,
CASE WHEN C.DEPARTAMENTO_SV='COLOMBIA' THEN NULL ELSE D.REGION END AS REGION_SV
FROM mdlo_contractual.cleansed.secop1 C 
LEFT JOIN mdlo_contractual.insumos.correcciones_municipios_departamentos_sv CM ON CM.DEPARTAMENTO_SV=C.DEPARTAMENTO_SV AND CM.MUNICIPIO_SV=C.MUNICIPIO_SV
LEFT JOIN mdlo_contractual.insumos.divipola D ON CM.MUNICIPIO_STD=D.NOMBRE_MUNICIPIO AND CM.DEPARTAMENTO_STD=D.NOMBRE_DEPARTAMENTO
LEFT JOIN mdlo_contractual.insumos.sujetos_control_depurada SC ON SC.NIT_ENTIDAD=C.NIT_ENTIDAD""")#.persist(StorageLevel.MEMORY_AND_DISK)
df2=spark.sql(f"""
SELECT C.* EXCEPT(C.SECTOR),SC.CONTRALORIA_DELEGADA,COALESCE(SC.SECTOR,C.SECTOR) AS SECTOR,SC.SUBSECTOR,
CASE WHEN C.DEPARTAMENTO_SV='COLOMBIA' THEN C.DEPARTAMENTO_SV ELSE COALESCE(D.DEPTO_AJUST,PD.DEPTO_AJUST) END AS DEPTO_AJUST,
CASE WHEN C.DEPARTAMENTO_SV='COLOMBIA' THEN C.MUNICIPIO_SV ELSE COALESCE(D.MUNI_AJUST,PD.MUNI_AJUST)END AS MUNI_AJUST,
CASE WHEN C.DEPARTAMENTO_SV='COLOMBIA' THEN NULL ELSE D.REGION END AS REGION_SV
FROM mdlo_contractual.cleansed.secop2 C 
LEFT JOIN mdlo_contractual.insumos.correcciones_municipios_departamentos_sv CM ON CM.DEPARTAMENTO_SV=C.DEPARTAMENTO_SV AND CM.MUNICIPIO_SV=C.MUNICIPIO_SV
LEFT JOIN mdlo_contractual.insumos.divipola D ON CM.MUNICIPIO_STD=D.NOMBRE_MUNICIPIO AND CM.DEPARTAMENTO_STD=D.NOMBRE_DEPARTAMENTO
LEFT JOIN mdlo_contractual.insumos.capitales_divipola PD ON CM.DEPARTAMENTO_STD=PD.NOMBRE_DEPARTAMENTO
LEFT JOIN mdlo_contractual.insumos.sujetos_control_depurada SC ON SC.NIT_ENTIDAD=C.NIT_ENTIDAD""")#.persist(StorageLevel.MEMORY_AND_DISK)
df3=df1.unionByName(df2,allowMissingColumns=True).dropDuplicates(subset=['ID_CONTRATO']).persist(StorageLevel.MEMORY_AND_DISK)
df3.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.reporting.contratacion_secop')
df3.unpersist()

# COMMAND ----------

ruta_base = 'abfss://sandbox@sadiaribigdata.dfs.core.windows.net/analista16/MDLO_CONTRACTUAL/Correcciones_contratacion/' 
buscar_csv = spark.read.format("com.crealytics.spark.excel").option("useHeader", "true").option('header','true').option("inferSchema", "true").load(ruta_base+'CORRECCIONES_MANUALES_UT_CS.xlsx')
# # ruta del azure storage explorer
buscar_csv.write.option("overwriteSchema", "true").mode("overwrite").saveAsTable(f"mdlo_contractual.insumos.correcciones_manuales_ut_cs")
buscar_csv = spark.read.csv(ruta_base+'CORRECCIONES_MANUALES_VALORES_SECOP.csv', header=True, encoding='ISO-8859-1',sep=";")
buscar_csv.write.option("overwriteSchema", "true").mode("overwrite").saveAsTable(f"mdlo_contractual.insumos.correcciones_valor_secop")

# COMMAND ----------

# DBTITLE 1,Corrección a valor de contratos ya identificados
# MAGIC %sql
# MAGIC MERGE INTO mdlo_contractual.reporting.contratacion_secop AS target
# MAGIC USING mdlo_contractual.insumos.correcciones_valor_secop AS source
# MAGIC ON target.ID_CONTRATO = source.ID_CONTRATO 
# MAGIC WHEN MATCHED THEN UPDATE SET target.VALOR_TOTAL_CONTRATO = source.VALOR_CONTRATO_NUEVO

# COMMAND ----------

if tipo_cargue=='TOTAL':
    spark.sql("""CREATE OR REPLACE TABLE mdlo_contractual.reporting.contratacion_secop_hist AS 
    SELECT * FROM mdlo_contractual.reporting.contratacion_secop""")

# COMMAND ----------

# DBTITLE 1,Delta de cargue en SECOP histórico
df3=spark.sql(f"SELECT * FROM mdlo_contractual.reporting.contratacion_secop N LEFT ANTI JOIN mdlo_contractual.reporting.contratacion_secop_hist O ON O.ID_CONTRATO = N.ID_CONTRATO")
df3.write.format("delta").mode("append").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.reporting.contratacion_secop_hist')
df3.unpersist()

# COMMAND ----------

# DBTITLE 1,Corregir información de UT/Consorcios
#ANTI JOIN mdlo_contractual.insumos.correcciones_ut_consorcios CC ON C.NOMBRE_CONTRATISTA=CC.NOMBRE_CONTRATISTA 
df_base=spark.sql(f"""SELECT DISTINCT NOMBRE_CONTRATISTA FROM mdlo_contractual.reporting.contratacion_secop C ANTI JOIN mdlo_contractual.insumos.correcciones_ut_consorcios CC ON C.NOMBRE_CONTRATISTA=CC.NOMBRE_CONTRATISTA  
WHERE IDENTIFICACION_CONTRATISTA = 'NO DEFINIDO' AND CLASIFICACION_CONTRATISTA_STD IN ('UT','CONSORCIOS')""")
df_opciones = spark.sql("SELECT DISTINCT ID_ENTIDAD,NOMBRE_ENTIDAD AS SUJETO_CONTROL FROM mdlo_contractual.reporting.integrantes UNION SELECT DISTINCT IDENTIFICACION_CONTRATISTA,NOMBRE_CONTRATISTA FROM mdlo_contractual.reporting.contratacion_sia WHERE CLASIFICACION_CONTRATISTA_STD IN ('UT','CONSORCIOS') UNION SELECT DISTINCT IDENTIFICACION_CONTRATISTA,NOMBRE_CONTRATISTA FROM mdlo_contractual.reporting.contratacion_sireci WHERE CLASIFICACION_CONTRATISTA_STD IN('UT','CONSORCIOS')")
df_opciones_pandas=df_opciones.toPandas()
def encontrar_nit_entidad(palabra):
    lista_opciones=df_opciones_pandas.SUJETO_CONTROL.unique()
    try:
        nombre_depurado, similarity_score, index = process.extractOne(f'{palabra}',lista_opciones,scorer=fuzz.token_sort_ratio,score_cutoff=95)
        if nombre_depurado is not None:
            return nombre_depurado
        else:
            return 'SIN COINCIDENCIA'
    except:
        return 'NO DEFINIDO'
@pandas_udf("string")
def encontrar_nit_entidad_udf(col_palabra):
    return pd.Series([encontrar_nit_entidad(palabra) for palabra in col_palabra])
df_base =df_base.withColumn('NOMBRE_DEPURADO', encontrar_nit_entidad_udf(col('NOMBRE_CONTRATISTA'))).persist(StorageLevel.MEMORY_AND_DISK)
df_base=df_base.where('NOMBRE_DEPURADO != "SIN COINCIDENCIA" AND NOMBRE_DEPURADO != "NO DEFINIDO"')
df_depurado=df_base.join(df_opciones,df_base['NOMBRE_DEPURADO']==df_opciones['SUJETO_CONTROL'],'inner').drop('SUJETO_CONTROL')
df_depurado.write.format("delta").mode("append").saveAsTable('mdlo_contractual.insumos.correcciones_ut_consorcios')
# df_depurado.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.insumos.correcciones_ut_consorcios')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(1),count(distinct NOMBRE_DEPURADO)
# MAGIC from mdlo_contractual.insumos.correcciones_ut_consorcios
# MAGIC WHERE NOMBRE_DEPURADO IN
# MAGIC (SELECT NOMBRE_DEPURADO
# MAGIC FROM mdlo_contractual.insumos.correcciones_ut_consorcios
# MAGIC --WHERE SIZE(SPLIT(NOMBRE_DEPURADO,r'\s+'))<3
# MAGIC GROUP BY NOMBRE_DEPURADO 
# MAGIC HAVING COUNT(1)=1)

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH PRE AS (SELECT *
# MAGIC from mdlo_contractual.insumos.correcciones_ut_consorcios
# MAGIC WHERE NOMBRE_DEPURADO IN
# MAGIC (SELECT NOMBRE_DEPURADO
# MAGIC FROM mdlo_contractual.insumos.correcciones_ut_consorcios
# MAGIC --WHERE SIZE(SPLIT(NOMBRE_DEPURADO,r'\s+'))<3
# MAGIC GROUP BY NOMBRE_DEPURADO 
# MAGIC HAVING COUNT(1)=1))
# MAGIC MERGE INTO mdlo_contractual.reporting.contratacion_secop AS target
# MAGIC USING PRE AS source
# MAGIC ON target.NOMBRE_CONTRATISTA = source.NOMBRE_CONTRATISTA
# MAGIC WHEN MATCHED THEN UPDATE SET target.IDENTIFICACION_CONTRATISTA = source.ID_ENTIDAD

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE mdlo_contractual.insumos.correcciones_estandarizar_nombres AS (
# MAGIC WITH UNIVERSO AS (SELECT NIT_ENTIDAD AS ID,NOMBRE_ENTIDAD AS NOMBRE FROM mdlo_contractual.reporting.contratacion_secop UNION ALL SELECT NIT_ENTIDAD,NOMBRE_ENTIDAD FROM mdlo_contractual.reporting.contratacion_sia UNION ALL SELECT NIT_ENTIDAD,NOMBRE_ENTIDAD FROM mdlo_contractual.reporting.contratacion_sireci UNION ALL SELECT IDENTIFICACION_CONTRATISTA AS ID,NOMBRE_CONTRATISTA AS NOMBRE FROM mdlo_contractual.reporting.contratacion_secop UNION ALL SELECT IDENTIFICACION_CONTRATISTA,NOMBRE_CONTRATISTA FROM mdlo_contractual.reporting.contratacion_sia UNION ALL SELECT IDENTIFICACION_CONTRATISTA,NOMBRE_CONTRATISTA FROM mdlo_contractual.reporting.contratacion_sireci),
# MAGIC PRE AS (SELECT ID,NOMBRE,COUNT(1) AS NUM_OCURRENCES
# MAGIC FROM UNIVERSO
# MAGIC GROUP BY ID,NOMBRE
# MAGIC ),
# MAGIC PRE2 AS (
# MAGIC SELECT ID,NOMBRE,
# MAGIC ROW_NUMBER() OVER (PARTITION BY ID ORDER BY NUM_OCURRENCES DESC,NOMBRE DESC) row
# MAGIC FROM PRE)
# MAGIC
# MAGIC SELECT * EXCEPT(row) FROM PRE2
# MAGIC WHERE row=1)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(1),count(distinct IDENTIFICACION) FROM mdlo_contractual.insumos.consultas_dian LIMIT 10

# COMMAND ----------

# DBTITLE 1,Consolidación contratación
df1=spark.sql(f"""SELECT C.*except(CLASIFICACION_ENTIDAD_STD,CLASIFICACION_CONTRATISTA_STD),COALESCE(NULLIF(CDE.NOMBRE_DIAN,'NO ENCONTRADO'),NE.NOMBRE) AS NOMBRE_ENTIDAD_STD,COALESCE(NULLIF(CDC.NOMBRE_DIAN,'NO ENCONTRADO'),NC.NOMBRE) AS NOMBRE_CONTRATISTA_STD,C.CLASIFICACION_ENTIDAD_STD,C.CLASIFICACION_CONTRATISTA_STD FROM mdlo_contractual.reporting.contratacion_secop C
LEFT JOIN mdlo_contractual.insumos.correcciones_estandarizar_nombres NE ON C.NIT_ENTIDAD=NE.ID 
LEFT JOIN mdlo_contractual.insumos.consultas_dian CDE ON C.NIT_ENTIDAD=CDE.IDENTIFICACION
LEFT JOIN mdlo_contractual.insumos.correcciones_estandarizar_nombres NC ON C.IDENTIFICACION_CONTRATISTA=NC.ID
LEFT JOIN mdlo_contractual.insumos.consultas_dian CDC ON C.IDENTIFICACION_CONTRATISTA=CDC.IDENTIFICACION""")#.persist(StorageLevel.MEMORY_AND_DISK)
df2=spark.sql(f"""
SELECT C.* except(REGION_SV,C.CLASIFICACION_ENTIDAD_STD,CLASIFICACION_CONTRATISTA_STD),CASE WHEN C.DEPARTAMENTO_SV='COLOMBIA' THEN C.DEPARTAMENTO_SV ELSE D.DEPTO_AJUST END AS DEPTO_AJUST,
CASE WHEN C.DEPARTAMENTO_SV='COLOMBIA' THEN C.MUNICIPIO_SV ELSE D.MUNI_AJUST END AS MUNI_AJUST,
CASE WHEN C.DEPARTAMENTO_SV='COLOMBIA' THEN NULL ELSE D.REGION END AS REGION_SV,COALESCE(NULLIF(CDE.NOMBRE_DIAN,'NO ENCONTRADO'),NE.NOMBRE) AS NOMBRE_ENTIDAD_STD,COALESCE(NULLIF(CDC.NOMBRE_DIAN,'NO ENCONTRADO'),NC.NOMBRE) AS NOMBRE_CONTRATISTA_STD,C.CLASIFICACION_ENTIDAD_STD,C.CLASIFICACION_CONTRATISTA_STD
FROM mdlo_contractual.reporting.contratacion_sia C
ANTI JOIN mdlo_contractual.reporting.contratacion_secop S ON S.NIT_ENTIDAD=C.NIT_ENTIDAD 
AND (S.IDENTIFICACION_CONTRATISTA=C.IDENTIFICACION_CONTRATISTA OR S.NOMBRE_CONTRATISTA=C.NOMBRE_CONTRATISTA)
AND abs(datediff(S.FECHA_SUSCRIPCION,C.FECHA_SUSCRIPCION))<=7
--AND abs(S.VALOR_TOTAL_CONTRATO - C.VALOR_TOTAL_CONTRATO)<100000
LEFT JOIN mdlo_contractual.insumos.correcciones_estandarizar_nombres NE ON C.NIT_ENTIDAD=NE.ID 
LEFT JOIN mdlo_contractual.insumos.consultas_dian CDE ON C.NIT_ENTIDAD=CDE.IDENTIFICACION
LEFT JOIN mdlo_contractual.insumos.correcciones_estandarizar_nombres NC ON C.IDENTIFICACION_CONTRATISTA=NC.ID
LEFT JOIN mdlo_contractual.insumos.consultas_dian CDC ON C.IDENTIFICACION_CONTRATISTA=CDC.IDENTIFICACION
LEFT JOIN mdlo_contractual.insumos.correcciones_municipios_departamentos_sv CM ON CM.DEPARTAMENTO_SV=C.DEPARTAMENTO_SV AND CM.MUNICIPIO_SV=C.MUNICIPIO_SV
LEFT JOIN mdlo_contractual.insumos.divipola D ON CM.MUNICIPIO_STD=D.NOMBRE_MUNICIPIO
AND CM.DEPARTAMENTO_STD=D.NOMBRE_DEPARTAMENTO 
WHERE C.ID_CONTRATO IN (SELECT CONTRATO_ID FROM mdlo_contractual.staging.sia WHERE SE_PUBLICO_EN_EL_SECOP = 'NO')
--WHERE S.ID_CONTRATO IS NULL
""").persist(StorageLevel.MEMORY_AND_DISK)
df3=df1.unionByName(df2,allowMissingColumns=True).dropDuplicates(subset=['ID_CONTRATO']).persist(StorageLevel.MEMORY_AND_DISK)
df3.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.reporting.contratacion_consolidada')
df1.unpersist()
df2.unpersist()
df3.unpersist()

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO mdlo_contractual.reporting.contratacion_consolidada AS target
# MAGIC USING mdlo_contractual.insumos.correcciones_manuales_ut_cs AS source
# MAGIC ON target.ID_CONTRATO = source.ID_CONTRATO
# MAGIC WHEN MATCHED THEN UPDATE SET target.IDENTIFICACION_CONTRATISTA = source.IDENTIFICACION_CONTRATISTA,target.NOMBRE_CONTRATISTA = source.NOMBRE_CONTRATISTA,target.VALOR_TOTAL_CONTRATO = source.VALOR_TOTAL_CONTRATO

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO mdlo_contractual.reporting.contratacion_consolidada AS target
# MAGIC USING mdlo_contractual.insumos.correcciones_recuperados_pdf_fase1 AS source
# MAGIC ON target.ID_CONTRATO = source.ID_CONTRATO
# MAGIC WHEN MATCHED THEN UPDATE SET target.IDENTIFICACION_CONTRATISTA = source.IDENTIFICACION_CONTRATISTA

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE mdlo_contractual.reporting.contratacion_consolidada

# COMMAND ----------

#Duplicar tabla y apendar SIRECI
df1=spark.sql(f"SELECT * FROM mdlo_contractual.reporting.contratacion_consolidada LIMIT 0")#.persist(StorageLevel.MEMORY_AND_DISK)
df2=spark.sql(f"""
SELECT C.* EXCEPT(STRFECBAL, RIESGOS_ASEGURADOS, PORCEN_AVA_FIS_PROGR, PORCEN_AVA_FIS_REAL, PORCEN_AVA_PRESUP_PROGR, PORCEN_AVA_PRESUP_REAL, ID_SUPERVISOR, NOMBRE_SUPERVISOR, ID_INTERVENTOR, NOMBRE_INTERVENTOR, CANTIDAD_REGISTRADO,TIPO_GARANTIA,ADICIONES,ANTICIPOS_O_PAGOS_ANTICIPADOS,MUNICIPIO_SV),D.MUNI_AJUST AS MUNICIPIO_SV,CASE WHEN C.DEPARTAMENTO_SV='COLOMBIA' THEN C.DEPARTAMENTO_SV ELSE D.DEPTO_AJUST END AS DEPTO_AJUST,D.MUNI_AJUST,D.REGION AS REGION_SV,COALESCE(NULLIF(CDE.NOMBRE_DIAN,'NO ENCONTRADO'),NE.NOMBRE) AS NOMBRE_ENTIDAD_STD,COALESCE(NULLIF(CDC.NOMBRE_DIAN,'NO ENCONTRADO'),NC.NOMBRE) AS NOMBRE_CONTRATISTA_STD
FROM mdlo_contractual.reporting.contratacion_sireci C
ANTI JOIN mdlo_contractual.reporting.contratacion_consolidada S ON S.NIT_ENTIDAD=C.NIT_ENTIDAD
AND (S.IDENTIFICACION_CONTRATISTA=C.IDENTIFICACION_CONTRATISTA OR S.NOMBRE_CONTRATISTA=C.NOMBRE_CONTRATISTA OR S.NUMERO_CONTRATO=C.NUMERO_CONTRATO)
AND (abs(datediff(S.FECHA_SUSCRIPCION,C.FECHA_SUSCRIPCION))<=7 OR abs(S.VALOR_TOTAL_CONTRATO - C.VALOR_TOTAL_CONTRATO)<100000)
LEFT JOIN mdlo_contractual.insumos.correcciones_estandarizar_nombres NE ON C.NIT_ENTIDAD=NE.ID 
LEFT JOIN mdlo_contractual.insumos.consultas_dian CDE ON C.NIT_ENTIDAD=CDE.IDENTIFICACION
LEFT JOIN mdlo_contractual.insumos.correcciones_estandarizar_nombres NC ON C.IDENTIFICACION_CONTRATISTA=NC.ID
LEFT JOIN mdlo_contractual.insumos.consultas_dian CDC ON C.IDENTIFICACION_CONTRATISTA=CDC.IDENTIFICACION
LEFT JOIN mdlo_contractual.insumos.correcciones_municipios_departamentos_sv CM ON CM.DEPARTAMENTO_SV=C.DEPARTAMENTO_SV AND CM.MUNICIPIO_SV='NO DEFINIDO'
LEFT JOIN mdlo_contractual.insumos.capitales_divipola D ON CM.DEPARTAMENTO_STD=D.NOMBRE_DEPARTAMENTO
AND CM.DEPARTAMENTO_STD=D.NOMBRE_DEPARTAMENTO """).persist(StorageLevel.MEMORY_AND_DISK)
df3=df1.unionByName(df2,allowMissingColumns=True).dropDuplicates(subset=['ID_CONTRATO'])#.persist(StorageLevel.MEMORY_AND_DISK)
df3.write.format("delta").mode("append").saveAsTable('mdlo_contractual.reporting.contratacion_consolidada')
df2.unpersist()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT FUENTE,COUNT(1)
# MAGIC FROM mdlo_contractual.reporting.contratacion_consolidada
# MAGIC GROUP BY FUENTE
# MAGIC --WHERE FUENTE = 'SIA'

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE mdlo_contractual.reporting.contratacion_consolidada

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC UPDATE mdlo_contractual.reporting.contratacion_consolidada SET IDENTIFICACION_CONTRATISTA =  mdlo_contractual.reporting.limpieza_id_sencilla(IDENTIFICACION_CONTRATISTA);
# MAGIC
# MAGIC UPDATE mdlo_contractual.reporting.contratacion_consolidada
# MAGIC SET IDENTIFICACION_CONTRATISTA = REPLACE(IDENTIFICACION_CONTRATISTA, ' ', '')
# MAGIC WHERE IDENTIFICACION_CONTRATISTA != 'NO DEFINIDO';
# MAGIC
# MAGIC UPDATE mdlo_contractual.reporting.contratacion_consolidada
# MAGIC SET IDENTIFICACION_CONTRATISTA = 
# MAGIC CASE 
# MAGIC     WHEN TRY_CAST(IDENTIFICACION_CONTRATISTA AS BIGINT) IS NOT NULL THEN CAST(IDENTIFICACION_CONTRATISTA AS BIGINT)
# MAGIC     ELSE IDENTIFICACION_CONTRATISTA
# MAGIC END;
# MAGIC
# MAGIC UPDATE mdlo_contractual.reporting.contratacion_consolidada SET IDENTIFICACION_CONTRATISTA = 'NO DEFINIDO' 
# MAGIC WHERE IDENTIFICACION_CONTRATISTA = '0' 
# MAGIC OR LEN(IDENTIFICACION_CONTRATISTA) <= 4
# MAGIC OR IDENTIFICACION_CONTRATISTA REGEXP '^0+$|^1+$|^2+$|^3+$|^4+$|^5+$|^6+$|^7+$|^8+$|^9+$';
# MAGIC
# MAGIC UPDATE mdlo_contractual.reporting.contratacion_consolidada SET IDENTIFICACION_CONTRATISTA = '901767095' WHERE ID_CONTRATO = 'CO1.PCCNTR.5488701';
# MAGIC UPDATE mdlo_contractual.reporting.contratacion_consolidada SET IDENTIFICACION_CONTRATISTA = '901840087' WHERE ID_CONTRATO = 'CO1.PCCNTR.6403111';
# MAGIC UPDATE mdlo_contractual.reporting.contratacion_consolidada SET NOMBRE_CONTRATISTA = 'EMPRESA PARA EL DESARROLLO TERRITORIAL - PROYECTA' WHERE ID_CONTRATO = '23-12-13661939-12656936' OR ID_CONTRATO = '22-12-13374099-12390593';
# MAGIC UPDATE mdlo_contractual.reporting.contratacion_consolidada SET NOMBRE_CONTRATISTA_STD = 'EMPRESA PARA EL DESARROLLO TERRITORIAL - PROYECTA' WHERE ID_CONTRATO = '23-12-13661939-12656936' OR ID_CONTRATO = '22-12-13374099-12390593';