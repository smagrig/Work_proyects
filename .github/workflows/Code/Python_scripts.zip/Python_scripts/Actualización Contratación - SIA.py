# Databricks notebook source
# MAGIC %md 
# MAGIC <h1> NO EDITAR, POR FAVOR CLONARLO Y TRABAJAR EN SU PROPIO WORKSPACE <h/1>

# COMMAND ----------

import sys
import os
# Agrega la ruta de la carpeta Funciones al path del sistema
sys.path.insert(1, os.path.join(r'/Workspace/Shared/produccion/MDLO_CONTRACTUAL', "Modules"))
from datetime import date
from pyspark.sql.types import *
from pyspark.sql.functions import approxCountDistinct,col,pandas_udf,udf,when,create_map,lit
from itertools import chain
from pyspark import StorageLevel
import cleaning_functions_DIARI as cf
fecha_actual=str(date.today())
anio_actual=date.today().year

# COMMAND ----------

# DBTITLE 1,Cargue de SIA a staging
query=f"""CREATE OR REPLACE TABLE mdlo_contractual.staging.sia AS
SELECT *
FROM cd_just.`830065741`.sia_1_fuente_nvo
"""
spark.sql(query)

# COMMAND ----------

# DBTITLE 1,Limpieza y cargue a cleansed
query=f"""
CREATE OR REPLACE TABLE mdlo_contractual.cleansed.sia AS
SELECT 
'SIA' AS FUENTE,
CONTRATO_ID AS ID_CONTRATO,
mdlo_contractual.reporting.limpieza_dv_sencilla(mdlo_contractual.reporting.limpieza_id_sencilla(NIT_SUJETO_VIGILADO)) AS NIT_ENTIDAD,
mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(NOMBRE_SUJETO_VIGILADO)) AS NOMBRE_ENTIDAD,
CASE WHEN MUNICIPIO_SUJETO_VIGILADO LIKE '%BOGOT%' THEN 'BOGOTA D C'
WHEN MUNICIPIO_SUJETO_VIGILADO LIKE '%MEDELL%' THEN 'ANTIOQUIA' ELSE mdlo_contractual.reporting.limpieza_texto_sencilla(DEPARTAMENTO_SUJETO_VIGILADO) END AS DEPARTAMENTO_SV,
mdlo_contractual.reporting.limpieza_texto_sencilla(MUNICIPIO_SUJETO_VIGILADO) AS MUNICIPIO_SV,
mdlo_contractual.reporting.limpieza_dv_sencilla(mdlo_contractual.reporting.limpieza_id_sencilla(IDENTIFICACION_CONTRATISTA)) AS IDENTIFICACION_CONTRATISTA,mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(NOMBRE_COMPLETO_DEL_CONTRATISTA)) AS NOMBRE_CONTRATISTA,
CASE WHEN LEFT(mdlo_contractual.reporting.limpieza_dv_sencilla(mdlo_contractual.reporting.limpieza_id_sencilla(IDENTIFICACION_CONTRATISTA)),1) IN (8,9) AND LENGTH(mdlo_contractual.reporting.limpieza_dv_sencilla(mdlo_contractual.reporting.limpieza_id_sencilla(IDENTIFICACION_CONTRATISTA)))=9 THEN 'NIT' WHEN IDENTIFICACION_CONTRATISTA RLIKE r'[A-Z]' THEN 'OTRO' ELSE 'CC' END AS TIPO_ID_CONTRATISTA,
CAST(TO_TIMESTAMP(FECHA_DE_SUSCRIPCION_DEL_CONTRATO,'M/d/yyyy hh:mm:ss a') AS DATE) AS FECHA_SUSCRIPCION,
CAST(VALOR_TOTAL_DEL_CONTRATO AS BIGINT) AS VALOR_TOTAL_CONTRATO,
mdlo_contractual.reporting.limpieza_texto_sencilla(OBJETO_DEL_CONTRATO) AS OBJETO_CONTRATO,
CASE WHEN ANIO IS NULL OR ANIO = '0' THEN YEAR(CAST(TO_TIMESTAMP(FECHA_DE_SUSCRIPCION_DEL_CONTRATO,'M/d/yyyy hh:mm:ss a') AS DATE) ) ELSE ANIO END AS ANO_SUSCRIPCION,
CAST(VALOR_INICIAL_DEL_CONTRATO AS BIGINT) AS VALOR_INICIAL_CONTRATO,
UPPER(MUNICIPIO_DE_EJECUCION) AS MUNICIPIO_EJECUCION_1,
UPPER(DEPARTAMENTO_DE_EJECUCION) AS DEPARTAMENTO_EJECUCION_1,
REGION AS REGION_SV,
CAST(TO_TIMESTAMP(FECHA_DE_TERMINACION_CON_PRORROGAS,'M/d/yyyy hh:mm:ss a') AS DATE) AS FECHA_FIN,
CAST(TO_TIMESTAMP(FECHA_DE_INICIO_DEL_CONTRATO,'M/d/yyyy hh:mm:ss a') AS DATE) AS FECHA_INICIO,
DATEDIFF(CAST(TO_TIMESTAMP(FECHA_DE_TERMINACION_CON_PRORROGAS,'M/d/yyyy hh:mm:ss a') AS DATE)
,CAST(TO_TIMESTAMP(FECHA_DE_TERMINACION_DEL_CONTRATO,'M/d/yyyy hh:mm:ss a') AS DATE)) AS TIEMPO_ADICIONES_DIAS,
mdlo_contractual.reporting.clasificacion_contratistas(mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(NOMBRE_SUJETO_VIGILADO))) AS CLASIFICACION_ENTIDAD_STD,
mdlo_contractual.reporting.clasificacion_contratistas(mdlo_contractual.reporting.limpieza_ut_cs(mdlo_contractual.reporting.limpieza_texto_sencilla(NOMBRE_COMPLETO_DEL_CONTRATISTA))) AS CLASIFICACION_CONTRATISTA_STD,
--CASE WHEN mdlo_contractual.reporting.limpieza_texto_sencilla(NOMBRE_COMPLETO_DEL_CONTRATISTA) RLIKE r'CONSORCIO|\\bU.?--T.?\\b|UNI.?NTEMPORAL|\\bCS\\b' THEN 1 ELSE 0 END AS MARCA_CONSORCIO_UT,
mdlo_contractual.reporting.limpieza_texto_sencilla(MODALIDAD_DE_SELECCION) AS MODALIDAD,
UPPER(TIPO_ENTIDAD_SUJETO_VIGILADO) AS NIVEL_ENTIDAD,
UPPER(TIPO_ENTIDAD_SUJETO_VIGILADO) AS ORDEN_ENTIDAD,
UPPER(ORIGEN_DEL_RUBRO_PRESUPUESTAL) AS ORIGEN_RECURSOS,
UPPER(TIPO_DE_GASTO) AS TIPO_GASTO,
REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(enlace_secop,r'(.*)%26g',r'$1'),r'%3d','='),r'%2f','/'),r'%3a',':'),r'%3f','?') AS ENLACE,
UPPER(CLASIFICACION_CONTRATISTA) AS TIPO_PERSONA_CONTRATISTA,
CAST(VALOR_TOTAL_DEL_CONTRATO-VALOR_INICIAL_DEL_CONTRATO AS BIGINT) AS VALOR_TOTAL_ADICIONES,
FECHA_CARGUE_CONTRATO AS FECHA_ACTUALIZACION,
mdlo_contractual.reporting.limpieza_texto_sencilla(PROCEDIMIENTO_CAUSAL) AS TIPO_DE_CONTRATO,
UPPER(SECTOR_AL_QUE_CORRESPONDE_EL_GASTO) AS SECTOR,
CASE WHEN UPPER(SUBSECTOR)='NO RERPORTADO POR LA ENTIDAD' THEN UPPER(SUBSECTOR) ELSE CONCAT('SUBSECTOR',UPPER(SUBSECTOR)) END AS SUBSECTOR,
PLAZO_DE_EJECUCION_CANTIDAD_DIAS AS DURACION_CONTRATO,
UPPER(ENTE_DE_CONTROL) AS CONTRALORIA_DELEGADA,
--SE_PACTO_ANTICIPO_AL_CONTRATO AS ANTICIPO,
VALOR_DE_LOS_ANTICIPOS AS VALOR_ANTICIPO,
--PRORROGA AS PRORROGA,
--ADICION AS ADICION,
--CESION AS CEDIDO,
'{fecha_actual}' AS FECHA_CARGA_UA
FROM mdlo_contractual.staging.sia
"""
spark.sql(query)

# COMMAND ----------

columnas_faltantes=['TIPO_ID_CONTRATISTA','CAUSAL_CONTRATACION_DIRECTA','NUMERO_CONTRATO','REGIMEN_DE_CONTRATACION','PLAZO_EJEC_CONTRATO','NUMERO_CONSTANCIA','ESTADO_CONTRATO','ESPOSTCONFLICTO','CODIGO_BPIN','NUMERO_PROCESO','NOMBRE_SEGMENTO','ID_SEGMENTO','NOMBRE_PRODUCTO','ID_PRODUCTO','NOMBRE_GRUPO','ID_GRUPO','NOMBRE_FAMILIA','ID_FAMILIA','NOMBRE_CLASE','ID_CLASE','NOMBRE_REP_LEGAL','IDENTIFICACION_REP_LEGAL','TIPO_ID_REP_LEGAL','DEPARTAMENTO_EJECUCION_3','MUNICIPIO_EJECUCION_3','DEPARTAMENTO_EJECUCION_2','MUNICIPIO_EJECUCION_2','COMPROMISO_PRESUPUESTAL','PROPONENTES_SELECCIONADOS','LIQUIDACION','ANNO_BPIN','ESTADO_BPIN','VALOR_AMORTIZADO','VALOR_FACTURADO','VALOR_PAGADO','REVERSION','ES_GRUPO','FECHA_FIN_EJECUCION','FECHA_INICIO_EJECUCION']

# COMMAND ----------

# DBTITLE 1,Limpiando texto en ciertas columnas de texto
df = spark.sql(f"SELECT * FROM mdlo_contractual.cleansed.sia").persist(StorageLevel.MEMORY_AND_DISK)
# # for column in columnas_faltantes:
# #     df = df.withColumn(column, lit("NO DEFINIDO"))
# cleaning_udf=udf(cf.limpieza_texto_sencilla)
# df = df.withColumn("NOMBRE_ENTIDAD", cleaning_udf(col("NOMBRE_ENTIDAD")))
# df = df.withColumn("NOMBRE_CONTRATISTA", cleaning_udf(col("NOMBRE_CONTRATISTA")))
# # df = df.withColumn("NOMBRE_REP_LEGAL", cleaning_udf(col("NOMBRE_REP_LEGAL")))
# df = df.withColumn("OBJETO_CONTRATO", cleaning_udf(col("OBJETO_CONTRATO")))
# df = df.withColumn("TIPO_DE_CONTRATO", cleaning_udf(col("TIPO_DE_CONTRATO")))
# df = df.withColumn("DEPARTAMENTO_SV", cleaning_udf(col("DEPARTAMENTO_SV")))
# df = df.withColumn("MUNICIPIO_SV", cleaning_udf(col("MUNICIPIO_SV")))
# df = df.withColumn("MODALIDAD", cleaning_udf(col("MODALIDAD")))

# COMMAND ----------

# DBTITLE 1,Limpiando identificación de entidad, contratista y representante legal
# cleaning_udf=udf(cf.limpieza_identificacion_sencilla)
# df = df.withColumn("NIT_ENTIDAD", cleaning_udf(col("NIT_ENTIDAD")))
# df = df.withColumn("IDENTIFICACION_CONTRATISTA", cleaning_udf(col("IDENTIFICACION_CONTRATISTA")))
# df = df.withColumn("IDENTIFICACION_REP_LEGAL", cleaning_udf(col("IDENTIFICACION_REP_LEGAL")))

# COMMAND ----------

# DBTITLE 1,Mapear tipos de manera correcta
mapping_expr = create_map([lit(x) for x in chain(*cf.replace_dict_departamento.items())])
# df = df.withColumn('DEPARTAMENTO_SV', mapping_expr[df['DEPARTAMENTO_SV']])

# COMMAND ----------

# print(df.select('DEPARTAMENTO_SV2','DEPARTAMENTO_SV').groupby('DEPARTAMENTO_SV2','DEPARTAMENTO_SV').count().display())

# COMMAND ----------

df = df.withColumn("TIEMPO_ADICIONES_DIAS", col("TIEMPO_ADICIONES_DIAS").cast(IntegerType()))
# df = df.withColumn("PLAZO_EJEC_CONTRATO", col("PLAZO_EJEC_CONTRATO").cast(IntegerType()))
df = df.withColumn("VALOR_INICIAL_CONTRATO", col("VALOR_INICIAL_CONTRATO").cast(DoubleType()))
df = df.withColumn("VALOR_TOTAL_CONTRATO", col("VALOR_TOTAL_CONTRATO").cast(DoubleType()))
df = df.withColumn("VALOR_TOTAL_ADICIONES", col("VALOR_TOTAL_ADICIONES").cast(DoubleType()))
df = df.withColumn("VALOR_ANTICIPO", col("VALOR_ANTICIPO").cast(DoubleType()))
# df = df.withColumn("VALOR_PAGADO", col("VALOR_PAGADO").cast(DoubleType()))
# df = df.withColumn("VALOR_AMORTIZADO", col("VALOR_AMORTIZADO").cast(DoubleType()))
# df = df.withColumn("VALOR_FACTURADO", col("VALOR_FACTURADO").cast(DoubleType()))
df = df.withColumn("FECHA_SUSCRIPCION", col("FECHA_SUSCRIPCION").cast(DateType()))
df = df.withColumn("FECHA_INICIO", col("FECHA_INICIO").cast(DateType()))
df = df.withColumn("FECHA_FIN", col("FECHA_FIN").cast(DateType()))
# df = df.withColumn("FECHA_INICIO_EJECUCION", col("FECHA_INICIO_EJECUCION").cast(DateType()))
# df = df.withColumn("FECHA_FIN_EJECUCION", col("FECHA_FIN_EJECUCION").cast(DateType()))
df = df.withColumn("FECHA_ACTUALIZACION", col("FECHA_ACTUALIZACION").cast(DateType()))
df = df.withColumn("FECHA_CARGA_UA", col("FECHA_CARGA_UA").cast(DateType()))
df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable('mdlo_contractual.reporting.contratacion_sia')
df.unpersist()
table_comment = "Información de contratación de SIA depurada"
query = f"COMMENT ON TABLE mdlo_contractual.reporting.contratacion_sia IS '{table_comment}'"
spark.sql(query)